package regexutility;

import org.junit.BeforeClass;
import org.junit.Test;

import edu.neumont.csc180.cox.regexutil.RegexHelper;
import junit.framework.Assert;

@SuppressWarnings("deprecation")
public class Tests {

	private static RegexHelper helper;
	
	@BeforeClass
	public static void init() {
		helper = new RegexHelper();
	}
	
	@Test
	public void testName() {
		boolean b = helper.isValidHumanName("Mr Joseph C Simpson");
		Assert.assertEquals(true, b);
	}
	
	@Test
	public void testEmail() {
		boolean b = helper.isValidEmailAddress("Aa@Google.com");
		Assert.assertEquals(true, b);
	}
	
	@Test
	public void testPhone() {
		boolean b = helper.isValidPhoneNumber("11-530-312-2940");
		Assert.assertEquals(true, b);
	}
	
	@Test
	public void testSSN() {
		boolean b = helper.isValidSSN("333-22-1111");
		Assert.assertEquals(true, b);
	}
	
	@Test
	public void streetTest() {
		boolean b = helper.isValidUSStreetAddress("9 north B9 south #590 \r\n" + 
				"AbC, AA 00000");
		Assert.assertEquals(true, b);
	}
	
	@Test
	public void testPassword() {
		boolean b = helper.validatePasswordComplexity("AAbb99--L", 9, 2, 2, 2, 2);
		Assert.assertEquals(true, b);
	}
	
	@Test
	public void testContains() {
		int i = helper.countContains("b", "AbA");
		Assert.assertEquals(1, i);
	}
	
	@Test
	public void testHTMLTag() {
		String str = helper.getHTMLTagContents("<div><div>Things</div></div>", "div");
		Assert.assertEquals("<div>Things</div>", str);
	}
	
	@Test
	public void testMultipleHTML() {
		String[] str = helper.getHTMLTagsContents("<div><div>Things</div></div> \r\n <div>Test</div>", "div");
		Assert.assertEquals("<div>Things</div>", str[1]);
		Assert.assertEquals("Test", str[2]);
	}
	
	@Test
	public void testLinks() {
		String[] str = helper.getHTMLLinkURL("<a href=AAA/> \r\n <a href=BBB/>");
		Assert.assertEquals("AAA", str[0]);
		Assert.assertEquals("BBB", str[1]);
	}
}
