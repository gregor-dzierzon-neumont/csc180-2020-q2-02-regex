package edu.neumont.csc180.cox.regexutil;


public class TestDriver {

	public static void main(String[] args) {
		System.out.println("<div><div>Things</div></div>");
		RegexHelper helper = new RegexHelper();
		String str = helper.getHTMLTagContents("<div><div>Things</div></div>", "div");
		
		System.out.println(str);

	}

}
