package edu.neumont.csc180.cox.regexutil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexHelper implements RegexUtility {

	private static final String humanName = "(Mr |Ms |Mrs |Mz )?[A-Z][a-z]*( [A-Z][a-z]*)? [A-Z][a-z]*";
	public boolean isValidHumanName(String name) {
		return name.matches(humanName);
	}

	private static final String emailCheck = "[A-Za-z]{1}([A-z_.0-9]*)[@][A-Z]{1}([A-z])*(\\.[A-Za-z0-9]{3,4})";
	public boolean isValidEmailAddress(String email) {
		return email.matches(emailCheck);
	}

	private static final String phoneCheck = "([0-9]{1,2}-)?[2-9][0-9]{2}-[2-9][0-9]{2}-[0-9]{4}";
	public boolean isValidPhoneNumber(String phone) {
		return phone.matches(phoneCheck);
	}

	private static final String ssnCheck = "(?!.*(000|666|9\\d\\d))[0-9]{3}-(?!.*(00))[0-9]{2}-(?!.*(0000))[0-9]{4}";
	public boolean isValidSSN(String ssn) {
		return ssn.matches(ssnCheck);
	}

	private static final String streetCheck = "[0-9]+ (north|south|east|west) ([A-Za-z0-9 ]+) (north|south|east|west) (Apt#|Suite#|#)[0-9]+ \r\n([A-Za-z ]+), [A-Z]{2}( |\r\n)([0-9]{5}|[0-9]{5}-[0-9]{4})";
	public boolean isValidUSStreetAddress(String street) {
		return street.matches(streetCheck);
	}

	public boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower,
			int minNumeric, int minSymbols) {
		boolean b = password.matches("^(.*[A-Z]){" + minUpper + "}.*$");
		b = password.matches("^(.*[a-z]){" + minLower + "}.*$");
		b = password.matches("^(.*[0-9]){" + minNumeric + "}.*$");
		b = password.matches("^(.*[@?<>*&^%$!\\{\\}\\[\\]\\/\\\\`~\\|:;#\\(\\)-_\\+=\\\"\\']){" + minSymbols + "}.*$");
		b = password.matches("^(.){" + minLength + "}$");
		return b;
	}

	public int countContains(String needle, String haystack) {
		Pattern p = Pattern.compile("(" + needle + ")");
		Matcher m = p.matcher(haystack);
		return m.groupCount();
	}

	public String getHTMLTagContents(String html, String tagName) {
		Pattern p = Pattern.compile("<" + tagName + ">" + "(.*)" + "<\\/" + tagName + ">");
		System.out.println(p.toString());
		Matcher m = p.matcher(html);
		System.out.println(m.toString());
		
		if(m.find()) {
		
		return m.group(1);
		}
		
		return null;
	}

	public String[] getHTMLTagsContents(String html, String tagName) {
		String[] contents = new String[10];
		
		Pattern p = Pattern.compile("<" + tagName + ">(.*)<\\/" + tagName + ">");
		Matcher m = p.matcher(html);
		
		//m.find();
		
		int i=1;
		while(m.find()) {
			contents[i] = m.group(1);
			System.out.println(m.group(1));
			i++;
		}
		return contents;
	}

	public String[] getHTMLLinkURL(String html) {
		String[] links = new String[10];
		Pattern p = Pattern.compile("<a href=(.*)\\/>");
		Matcher m = p.matcher(html);
		
		int i = 0;
		while(m.find()) {
			links[i] = m.group(1);
			i++;
		}
		
		return links;
	}

}
