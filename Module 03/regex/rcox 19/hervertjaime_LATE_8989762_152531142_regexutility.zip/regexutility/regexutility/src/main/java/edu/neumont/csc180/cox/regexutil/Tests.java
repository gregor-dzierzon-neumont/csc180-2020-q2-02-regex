package edu.neumont.csc180.cox.regexutil;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

public class Tests {

	
	@Test
	public void Human() {
		Utility u = new Utility();
	String name1 = "Jaime Hervert";
	String name2 = "Jaime I Hervert";
	String name3 = "Jaime Isaias Hervert";
	String name4 = "Mr Jaime Hervert";
	String name5 = "Mr Jaime I Hervert";
	String name6 = "Mr Jaime Isaias Hervert";
	
	
		Assert.assertTrue(u.isValidHumanName(name1));
		Assert.assertTrue(u.isValidHumanName(name2));
		Assert.assertTrue(u.isValidHumanName(name3));
		Assert.assertTrue(u.isValidHumanName(name4));
		Assert.assertTrue(u.isValidHumanName(name5));
		Assert.assertTrue(u.isValidHumanName(name6));
		
	}
	
	
	@Test
	public void Email() {
		Utility u = new Utility();
	String name1 = "JaimeHervert@gmail.com";
	String name2 = "Jaime123@gmail.com";
	String name3 = "jaime._@gmail.com";
	
	
	
		Assert.assertTrue(u.isValidEmailAddress(name1));
		Assert.assertTrue(u.isValidEmailAddress(name2));
		Assert.assertTrue(u.isValidEmailAddress(name3));
		
		
	}
	
	@Test
	public void Phone() {
		Utility u = new Utility();
		String name1 = "817-883-9324";
		String name2 = "1-234-543-3441";
		String name3 = "12-323-343-3423";
		
		
		
			Assert.assertTrue(u.isValidPhoneNumber(name1));
			Assert.assertTrue(u.isValidPhoneNumber(name2));
			Assert.assertTrue(u.isValidPhoneNumber(name3));
		
		
	}
	
	@Test
	public void SSN() {
		Utility u = new Utility();
		String name1 = "817-83-9324";
		String name2 = "234-53-3441";
		String name3 = "323-34-3423";
		
		
		
			Assert.assertTrue(u.isValidSSN(name1));
			Assert.assertTrue(u.isValidSSN(name2));
			Assert.assertTrue(u.isValidSSN(name3));		
	}
	
	
	@Test
	public void Address() {
		Utility u = new Utility();
		String name1 = "343 south 500 east \n Salt Lake City, UT 84102";
		
		Assert.assertTrue(u.isValidUSStreetAddress(name1));
		
		
	}
	
	@Test
	public void Complexity() {
		Utility u = new Utility();
		String name1 = "Jai2me3H!5";
		String name2 = "asdf$jsdf";
		String name3 = "2d3h4Js";
		
		
		
			Assert.assertTrue(u.validatePasswordComplexity(name1, 10, 2,4, 3, 1));
			Assert.assertTrue(u.validatePasswordComplexity(name2, 9, 0, 0, 0, 1));
			Assert.assertTrue(u.validatePasswordComplexity(name3, 7, 1, 2, 3, 0));		
	}
	
	@Test
	public void Count() {
		Utility u = new Utility();
		String name1 = "apple";
		Assert.assertEquals(2, u.countContains("p", name1));
				
	}
	
	
	@Test
	public void OneTag() {
		Utility u = new Utility();
		String s = "<div>sdfsdg</div><div>sdf</div>";
		Assert.assertEquals("sdfsdg", u.getHTMLTagContents(s, "div"));
		
		
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void ManyTags() {
		Utility u = new Utility();
		String s = "<div>sdfsdg</div><div>sdf</div>";
		String[] d = {"sdfsdg", "sdf"};
		Assert.assertEquals(d, u.getHTMLTagsContents(s, "div"));
		
		
	}
	
	@Test
	public void Links() {
		Utility u = new Utility();
		String s = "<a href=\"Google.com\"<a> <a href=\"Youtube.com\"><a>";
		String[] d = {"Google.com", "Youtube.com"};
		Assert.assertEquals(d, u.getHTMLLinkURL(s));
		
		
	}
	
	
}
