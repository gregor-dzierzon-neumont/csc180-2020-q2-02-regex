package edu.neumont.csc180.cox.regexutil;

public class Main {

	public static void main(String[] args) {
Utility u = new Utility();
String[] results = u.getHTMLLinkURL("<a href=\"boobs.com\"><a> insert text here cause i wanna <a href=\"Ass.com\"><a>");
for(String s: results)	{	
System.out.println(s);}

	}

}
