package edu.neumont.csc180.cox.regexutil;

public class Utility implements RegexUtility{

	@Override
	public boolean isValidHumanName(String name) {
		// TODO Auto-generated method stub
		return name.matches("(Mr(\\.| )|Ms(\\.| )|Miss(\\.| )|Mrs(\\.| )|Dr(\\.| ))?[A-Z][a-z]+\\s([A-Z][a-z]*\\s)?[A-Z][a-z]+");
	}

	@Override
	public boolean isValidEmailAddress(String email) {
		// TODO Auto-generated method stub
		return email.matches("[\\w\\.\\_]+@[A-Za-z][\\w]+.com");
	}

	@Override
	public boolean isValidPhoneNumber(String phone) {
		
		return phone.matches("(\\d(\\d)?-)?[2-9]\\d\\d-[2-9]\\d\\d-\\d\\d\\d\\d");
	}

	@Override
	public boolean isValidSSN(String ssn) {
		if(ssn.charAt(1)=='6'&&ssn.charAt(2)=='6'&&ssn.charAt(3)=='6') {
			return false;
		}
		return ssn.matches("[0-8]{2}[1-9]-\\d{2}-\\d\\d\\d\\d");
	}

	@Override
	public boolean isValidUSStreetAddress(String street) {
		// TODO Auto-generated method stub
		return street.matches("\\d+ (north|south|east|west)? [\\w ]+ (north|south|east|west)? ([1-9](\\d)?)?\\n [\\w ]+, [A-Z]{2}([\\n ])?\\d{5}(-\\d{4})?");
	}

	@Override
	public boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower,
			int minNumeric, int minSymbols) {
		boolean answer = true;
		
		char a = password.charAt(password.length()-1);
		
		int digits = password.split("\\d").length-1;
		int lower = password.split("[a-z]").length-1;
		int upper = password.split("[A-Z]").length-1;
		int Symbol = password.split("\\W").length-1;
		
		if(Character.isDigit(a)) {digits++;}
		else if(Character.isUpperCase(a)) {upper++;}
		else if(Character.isLowerCase(a)) {lower++;}
		else if(Character.valueOf(a)> 33 && Character.valueOf(a) < 126) {Symbol++;}
		
		if(password.length() < minLength) {answer = false;}
		else if(upper<minUpper) {answer = false;}
		else if(digits<minNumeric) {answer = false;}
		else if(lower<minLower) {answer = false;}	
		else if(Symbol<minSymbols) {answer = false;}
		

		
		return answer;
	}

	@Override
	public int countContains(String needle, String haystack) {
		
		int i = haystack.split(needle).length-1;
		if (haystack.endsWith(needle)) {i++;}
		return i;
	}

	@Override
	public String getHTMLTagContents(String html, String tagName) {

		int m = 1000000000;
		int i = html.indexOf("<"+tagName+">");
		i = i+2+tagName.length();
		int j = i;
		 m = html.indexOf("</"+tagName+">", j);
			
		while(j<m &&j != -1 ) {
		
		j = html.indexOf("<"+tagName+">", j-1);
		
		if(j< m && j!=-1) {
			m = html.indexOf("</"+tagName+">", m+tagName.length()+3);
			j = j+2+tagName.length();	
		} 
		}
		String returning = html.substring(i, m);
		
		
		return returning;
	}

	@Override
	public String[] getHTMLTagsContents(String html, String tagName) {
		String[] returns = new String[html.split("<"+tagName+">").length-1];
		String st = html;
		for(int z = 0; z< returns.length; z++) {

			int m = 1000000000;
			int i = st.indexOf("<"+tagName+">");
			i = i+2+tagName.length();
			int j = i;
			 m = st.indexOf("</"+tagName+">", j);
				
			while(j<m &&j != -1 ) {
			
			j = st.indexOf("<"+tagName+">", j-1);
			
			if(j< m && j!=-1) {
				m = st.indexOf("</"+tagName+">", m+tagName.length()+3);
				j = j+2+tagName.length();	
			} 
			}
			returns[z] = st.substring(i, m);
			
			st = st.substring(i);
			
			
		}
		
		
		return returns;
	}

	@Override
	public String[] getHTMLLinkURL(String html) {
		
		
		String[] returns = new String[html.split("<a href=\"").length-1];
		String st = html;
		for(int z = 0; z< returns.length; z++) {

			int m = 1000000000;
			int i = st.indexOf("<a href=\"");
			i = i+9;
			 m = st.indexOf("\"", i);
			returns[z] = st.substring(i, m);
			
			st = st.substring(m);
			
			
		}
		
		
		return returns;
		
	}

}
