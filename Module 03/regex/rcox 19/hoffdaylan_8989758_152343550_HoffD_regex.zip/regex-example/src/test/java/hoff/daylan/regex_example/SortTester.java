package hoff.daylan.regex_example;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class SortTester {
RegexHelper h = new RegexHelper();
	@Test
	public void checkValidAddress()  { 
		boolean b = h.isValidAdress("1535 South 1100 East #1435\nSalt Lake City, UT 84105-4100");

		assertEquals(b, true);
	}
	@Test
	public void checkInvalidAddress()  { 
		boolean b = h.isValidAdress("1535 South 1100 East");

		assertEquals(b, false);
	}
	@Test
	public void checkValidCount()  { 
		boolean b = h.isValidCount("1234567890");//10 chars

		assertEquals(b, true);
	}
	@Test
	public void checkInvalidCount()  { 
		boolean b = h.isValidCount("12345678910");//11 chars

		assertEquals(b, false);
	}
	@Test
	public void checkValidEmail()  { 
		boolean b = h.isValidEmail("dhoff@gmail.com");

		assertEquals(b, true);
	}
	@Test
	public void checkInvalidEmail()  { 
		boolean b = h.isValidEmail("google.com");

		assertEquals(b, false);
	}
	@Test
	public void checkValidName()  { 
		boolean b = h.isValidName("Daylan Hoff");

		assertEquals(b, true);
	}
	@Test
	public void checkInvalidName()  { 
		boolean b = h.isValidName("8008995");

		assertEquals(b, false);
	}
	@Test
	public void checkValidPhone()  { 
		boolean b = h.isValidNumber("+1 801-971-5001");

		assertEquals(b, true);
	}
	@Test
	public void checkInalidPhone()  { 
		boolean b = h.isValidNumber("5001");

		assertEquals(b, false);
	}
	@Test
	public void checkValidSSN()  { 
		boolean b = h.isValidSSN("650999999");

		assertEquals(b, true);
	}
	@Test
	public void checkInvalidSSN()  { 
		boolean b = h.isValidSSN("999999");

		assertEquals(b, false);
	}
	@Test
	public void checkValidInTag()  { 
		boolean b = h.GetInsideTag("div", "<div>Hello Wolrd</div>");

		assertEquals(b, true);
	}
	@Test
	public void checkInvalidInTag()  { 
		boolean b = h.GetInsideTag("div", "<span></span>");

		assertEquals(b, false);
	}
	@Test
	public void checkValidInAllTag()  { 
		boolean b = h.GetInsideTag("div", "<div>Hello Wolrd</div><div>Hello Wolrd</div>");

		assertEquals(b, true);
	}
	@Test
	public void checkInvalidInAllTag()  { 
		boolean b = h.GetInsideAllTag("div", "<span></span>");

		assertEquals(b, false);
	}
	@Test
	public void checkValidInWebTag()  { 
		boolean b = h.GetInsideAllWebTag("<a href = google.com </a>");

		assertEquals(b, true);
	}
	public void checkInalidInWebTag()  { 
		boolean b = h.GetInsideAllWebTag("<a plat = google.com </a>");

		assertEquals(b, false);
	}
}
