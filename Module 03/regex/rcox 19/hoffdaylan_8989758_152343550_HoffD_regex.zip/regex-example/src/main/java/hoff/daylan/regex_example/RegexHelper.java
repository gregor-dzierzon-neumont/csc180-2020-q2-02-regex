package hoff.daylan.regex_example;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexHelper {

	private static final String addressRegEx = "^\\d+ (?:North|East|South|West)+ \\d+ (?:North|East|South|West)+ (?:Apt#|Suite#|#)\\d+\\n(?:[A-Z][a-z.-]+[ ]?)+, (?:AL|AK|AS|AZ|AR|CA|CO|CT|DE|DC|FM|FL|GA|GU|HI|ID|IL|IN|IA|KS|KY|LA|ME|MH|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|MP|OH|OK|OR|PW|PA|PR|RI|SC|SD|TN|TX|UT|VT|VI|VA|WA|WV|WI|WY)(:? |\\n)\\d{5}-\\d{4}";

	private static final String phoneRegEx = "^(?:(?:\\+?1\\s*(?:[.-]\\s*)?)?(?:\\(\\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\\s*\\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\\s*(?:[.-]\\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\\s*(?:[.-]\\s*)?([0-9]{4})(?:\\s*(?:#|x\\.?|ext\\.?|extension)\\s*(\\d+))?$";

	private static final String emailRegEx = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$";

	private static final String SSNRegEx = "^(?!000|666)[0-9]{3}([ -]?)(?!00)[0-9]{2}\\1(?!0000)[0-9]{4}$";

	private static final String nameRegEx = "^[\\p{L} .'-]+$";

	private static final String countRegEx = "^.{1,10}$";

	public boolean isValidNumber(String phone) {
		if (phone.matches(phoneRegEx)) {
			System.out.println(phone + " is valid");
		} else {
			System.out.println(phone + " is not valid");
		}
		return phone.matches(phoneRegEx);
	}

	public boolean isValidAdress(String ady) {
		if (ady.matches(addressRegEx)) {
			System.out.println(ady + " is valid");
		} else {
			System.out.println(ady + " is not valid");
		}
		return ady.matches(addressRegEx);
	}

	public boolean isValidEmail(String email) {
		if (email.matches(emailRegEx)) {
			System.out.println(email + " is valid");
		} else {
			System.out.println(email + " is not valid");
		}
		return email.matches(emailRegEx);
	}

	public boolean isValidSSN(String ssn) {
		if (ssn.matches(SSNRegEx)) {
			System.out.println(ssn + " is valid");
		} else {
			System.out.println(ssn + " is not valid");
		}
		return ssn.matches(SSNRegEx);
	}

	public boolean isValidName(String ssn) {
		if (ssn.matches(nameRegEx)) {
			System.out.println(ssn + " is valid");
		} else {
			System.out.println(ssn + " is not valid");
		}
		return ssn.matches(nameRegEx);
	}

	public boolean isValidCount(String ssn) {
		if (ssn.matches(countRegEx)) {
			System.out.println(ssn + " is valid");
		} else {
			System.out.println(ssn + " is not valid");
		}
		return ssn.matches(countRegEx);
	}

	public boolean GetInsideTag(String tag, String inp) {
		boolean isin = false;
		Pattern pattern = Pattern.compile("<"+tag+">(.+?)</"+tag+">");
		Matcher matcher = null;
		if (!isin && inp.toLowerCase().contains("<"+tag+">")) {
			isin = true;
		}
		if (isin) {
			matcher = pattern.matcher(inp);
			if (matcher.find()) {
				System.out.println(matcher.group(1));
			}
		}
		return isin;
	}
	public boolean GetInsideAllTag(String tag, String inp) {
		boolean isin = false;
		Pattern pattern = Pattern.compile("<"+tag+">(.+?)</"+tag+">");
		Matcher matcher = null;
		if (!isin && inp.toLowerCase().contains("<"+tag+">")) {
			isin = true;
		}
		if (isin) {
			matcher = pattern.matcher(inp);
			while (matcher.find()) {
				System.out.println(matcher.group(1));
			}
		}
		return isin;
	}
	public boolean GetInsideAllWebTag(String inp) {
		boolean isin = false;
		Pattern pattern = Pattern.compile("\\s*(?i)href\\s*=\\s*(\"([^\"]*\")|'[^']*'|([^'\">\\s]+))");
		Matcher matcher = null;
		if (!isin && inp.toLowerCase().contains("href")) {
			isin = true;
		}
		if (isin) {
			matcher = pattern.matcher(inp);
			while (matcher.find()) {
				System.out.println(matcher.group(1));
			}
		}
		return isin;
	}
}
