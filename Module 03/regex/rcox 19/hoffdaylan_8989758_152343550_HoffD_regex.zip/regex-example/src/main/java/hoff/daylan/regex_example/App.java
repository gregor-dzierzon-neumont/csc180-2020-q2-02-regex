package hoff.daylan.regex_example;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	RegexHelper h = new RegexHelper();
    	//h.isValidTag("div", "<div>Hello</div><div>Hello</div>");
    	
    	//h.isValidAdress("1535 South 1100 East #1435\nSalt Lake City, UT 84105-4100");

    }
}