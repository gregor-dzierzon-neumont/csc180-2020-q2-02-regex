package byrd.riley.regexutil.models;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SimpleRegexUtil implements RegexUtility {

	public boolean isValidHumanName(String name) {
		String regex = "((([A-Z][a-z]{1,2}[.])|(Miss)) )?([A-Z][a-z]+) ((([A-Z][.])|([A-Z][a-z]+)) )?(([A-Za-z]{1,2}[']?)|([a-z]{0,3} )|())[A-Z][a-z]+";
		Pattern pat = Pattern.compile(regex, Pattern.MULTILINE);
		return pat.matcher(name).matches();
	}

	public boolean isValidEmailAddress(String email) {
		String regex = "([A-Za-z][\\w.]*)@([A-Za-z][A-Za-z0-9]*[.][A-Za-z]{3,4})";
		Pattern pat = Pattern.compile(regex, Pattern.MULTILINE);
		return pat.matcher(email).matches();
	}

	public boolean isValidPhoneNumber(String phone) {
		String regex = "^([1-9]|[0-9]{2})-([2-9](?!.*00|.*11|.*22|.*33|.*44|.*55|.*66|.*77|.*88|.*99)[0-8][0-9])-[2-9][0-9]{2}-[0-9]{4}$";
		Pattern pat = Pattern.compile(regex, Pattern.MULTILINE);
		return pat.matcher(phone).matches();
	}

	public boolean isValidSSN(String ssn) {
		String regex = "^(?!000|666|9[0-9]{2})[0-9]{3}-(?!00)[0-9]{2}-(?!0000)[0-9]{4}$";
		Pattern pat = Pattern.compile(regex, Pattern.MULTILINE);
		return pat.matcher(ssn).matches();
	}

	public boolean isValidUSStreetAddress(String street) {
		String regex = "([0-9]+)(?: ((?:[Nn](?:orth)?)|(?:[Ss](?:outh)?)|(?:[Ee](?:ast)?)|(?:[Ww](?:est)?)))? ((?:[A-Za-z0-9 ](?! [Nn](?:orth)? | [Ss](?:outh)? | [Ee](?:ast)? | [Ww](?:est)? ))+(?<=[A-Za-z])[a-z]?)(?: ((?:[Nn](?:orth)?)|(?:[Ss](?:outh)?)|(?:[Ee](?:ast)?)|(?:[Ww](?:est)?)))?(?: ((?:(?:Apt#)|(?:Suite#)|#)[0-9]+))?\\R((?:[A-Za-z ](?!,))+[a-z]), ?([A-Z]{2})[ \\n\\r]?([0-9]{5}(?:-[0-9]{4})?)";
		Pattern pat = Pattern.compile(regex, Pattern.MULTILINE);
		return pat.matcher(street).matches();
	}

	public boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower,
			int minNumeric, int minSymbols) {
		String regex = "^(?=.*.{" + minLength + "})(?=.*[A-Z]{" + minUpper + "})(?=.*[a-z]{" + minLower + "})(?=.*\\d{" + minNumeric + "})(?=.*[^A-Za-z0-9]{" + minSymbols + "}).*$";
		Pattern pat = Pattern.compile(regex);
		return pat.matcher(password).matches();
	}

	public int countContains(String needle, String haystack) {
		Pattern pat = Pattern.compile(needle, Pattern.MULTILINE);
		Matcher mat = pat.matcher(haystack);
		int count = 0;
		while(mat.find()) ++count;
		return count;
	}

	public String getHTMLTagContents(String html, String tagName) {
		String regex = "(<" + tagName + " \\/>)|(?:(<" + tagName + ".*>)(.*)(<\\/" + tagName + ">))";
		Pattern pat = Pattern.compile(regex, Pattern.MULTILINE);
		Matcher mat = pat.matcher(html);
		mat.find();
		return mat.group(3);
	}

	public String[] getHTMLTagsContents(String html, String tagName) {
		String regex = "(<" + tagName + " \\/>)|(?:(<" + tagName + ".*>)(.*)(<\\/" + tagName + ">))";
		Pattern pat = Pattern.compile(regex, Pattern.MULTILINE);
		Matcher mat = pat.matcher(html);
		ArrayList<String> matches = new ArrayList<>();
		String[] matchesArr = null;
		
		while(mat.find()) {
			String contents = mat.group(3);
			if(contents != null && !contents.trim().isEmpty()) {
				matches.add(contents);
			}
		}
		
		matchesArr = new String[matches.size()];
		matches.toArray(matchesArr);
		
		return matchesArr;
	}

	public String[] getHTMLLinkURL(String html) {
		String regex = "(<a.* href=\"(.*)\".*>)(.*)(<\\/a>)";
		Pattern pat = Pattern.compile(regex, Pattern.MULTILINE);
		Matcher mat = pat.matcher(html);
		ArrayList<String> matches = new ArrayList<>();
		String[] matchesArr = null;
		
		while(mat.find()) {
			String contents = mat.group(2);
			if(contents != null && !contents.trim().isEmpty()) {
				matches.add(contents);
			}
		}
		
		matchesArr = new String[matches.size()];
		matches.toArray(matchesArr);
		
		return matchesArr;
	}
}
