package byrd.riley.regexutil.test;

import org.junit.Assert;
import org.junit.Test;

import byrd.riley.regexutil.models.RegexUtility;
import byrd.riley.regexutil.models.SimpleRegexUtil;


public class RegexTester {

	@Test
	public void testIsValidHumanName() {
		String[] namesToValidate = { "Mr. Lucas T. McManus", "Mr. Lucas Thomas McManus",
			"Mr. Joshua R. van Antwerp", "Mr. Riley David Byrd", "Dr. Daniel F. Byrd",
			"Miss Daniell J. Ebert", "Mrs. Catherine di Medici", "Renate Craig", "Sr. Senior Senior" };
		
		RegexUtility regUtil = new SimpleRegexUtil();
		
		for(String name : namesToValidate) {
			boolean isValid = regUtil.isValidHumanName(name);
			Assert.assertEquals(true, isValid);
			System.out.println(isValid);
		}
		
		System.out.println();
		
		String[] namesToInvalidate = { "something blurb blah", "I wish I were", "Windows 10" };
		
		for(String name : namesToInvalidate) {
			boolean isValid = regUtil.isValidHumanName(name);
			Assert.assertNotEquals(true, isValid);
			System.out.println(isValid);
		}
	}
	
	@Test
	public void testIsValidEmailAddress() {
		String[] emailsToValidate = { "rbyrd.abyrd@gmail.com",
				"rbyrd17@pcc.edu",
				"riley_byrd@symantec.com" };
		
		RegexUtility regUtil = new SimpleRegexUtil();
		
		for(String email : emailsToValidate) {
			boolean isValid = regUtil.isValidEmailAddress(email);
			Assert.assertEquals(true, isValid);
		}
		
		String nonAlphBeginsEmail = "20troy@fun.gov";
		String longerThan4Domain = "fiftyfive@age.oldsville";
		
		Assert.assertEquals(false, regUtil.isValidEmailAddress(nonAlphBeginsEmail));
		Assert.assertEquals(false, regUtil.isValidEmailAddress(longerThan4Domain));
	}
	
	@Test
	public void testIsValidPhoneNumber() {
		RegexUtility regUtil = new SimpleRegexUtil();
		
		String zeroBeginsAreaCode = "11-012-345-6789";
		String lessThanTwoBeginsSubNum = "21-456-189-3567";
		String doubleEndsSubNum = "34-904-766-9843";
		
		String normalNum = "1-541-789-7643";
		
		Assert.assertEquals(false, regUtil.isValidPhoneNumber(zeroBeginsAreaCode));
		Assert.assertEquals(false, regUtil.isValidPhoneNumber(lessThanTwoBeginsSubNum));
		Assert.assertEquals(false, regUtil.isValidPhoneNumber(doubleEndsSubNum));
		
		Assert.assertEquals(true, regUtil.isValidPhoneNumber(normalNum));
	}
	
	@Test
	public void testIsValidSSN() {
		RegexUtility regUtil = new SimpleRegexUtil();
		
		String leadingTripleZero = "000-12-4567";
		String leadingNine = "912-81-7123";
		String trailingQuadrupleZero = "123-45-0000";
		
		String normalSSN = "555-77-9999";
		
		Assert.assertEquals(false, regUtil.isValidSSN(leadingTripleZero));
		Assert.assertEquals(false, regUtil.isValidSSN(leadingNine));
		Assert.assertEquals(false, regUtil.isValidSSN(trailingQuadrupleZero));
		
		Assert.assertEquals(true, regUtil.isValidSSN(normalSSN));
	}
	
	@Test
	public void testIsValidUSStreetAddress() {
		RegexUtility regUtil = new SimpleRegexUtil();

		String withOptionalFields =
			"644 W North Temple South Apt#419\r\n" + 
			"Salt Lake City, UT 84116-3456";
		
		String withoutOptionalFields =
			"610 13th St\r\n" + 
			"Mineral Wells,TX76067";
		
		String missingHouseNum =
			"W North Temple Apt#419\r\n" + 
			"Salt Lake City, UT 84116-3456";
		
		String letterInZip =
			"644 W North Temple South Apt#419\r\n" + 
			"Salt Lake City, UT 841a16-3456";
		
		Assert.assertEquals(true, regUtil.isValidUSStreetAddress(withOptionalFields));
		Assert.assertEquals(true, regUtil.isValidUSStreetAddress(withoutOptionalFields));
		Assert.assertEquals(false, regUtil.isValidUSStreetAddress(missingHouseNum));
		Assert.assertEquals(false, regUtil.isValidUSStreetAddress(letterInZip));
	}
	
	@Test
	public void testPasswordComplexity() {
		RegexUtility regUtil = new SimpleRegexUtil();
		
		String password = "ABcd56$%";
		
		int moreThanLength = password.length() + 1;
		int eachCharTypeCount = 2;
		int moreThanCharTypeCount = eachCharTypeCount + 1;
		
		Assert.assertEquals(false, regUtil.validatePasswordComplexity(password, moreThanLength, eachCharTypeCount, eachCharTypeCount, eachCharTypeCount, eachCharTypeCount));
		Assert.assertEquals(false, regUtil.validatePasswordComplexity(password, password.length(), moreThanCharTypeCount, eachCharTypeCount, eachCharTypeCount, eachCharTypeCount));
		Assert.assertEquals(false, regUtil.validatePasswordComplexity(password, password.length(), eachCharTypeCount, moreThanCharTypeCount, eachCharTypeCount, eachCharTypeCount));
		Assert.assertEquals(false, regUtil.validatePasswordComplexity(password, password.length(), eachCharTypeCount, eachCharTypeCount, moreThanCharTypeCount, eachCharTypeCount));
		Assert.assertEquals(false, regUtil.validatePasswordComplexity(password, password.length(), eachCharTypeCount, eachCharTypeCount, eachCharTypeCount, moreThanCharTypeCount));
		
		Assert.assertEquals(true, regUtil.validatePasswordComplexity(password, password.length(), eachCharTypeCount, eachCharTypeCount, eachCharTypeCount, eachCharTypeCount));
	}

	@Test
	public void testCountContains() {
		String needle = "needle";
		String haystack = "needle-ing the needler's haystack";
		
		RegexUtility regUtil = new SimpleRegexUtil();
		
		Assert.assertEquals(2, regUtil.countContains(needle, haystack));
	}
	
	@Test
	public void testGetHTMLTagContents() {
		String html =
			"<!DOCTYPE HTML>" +
			"<html>" +
			"<body>" +
			"<a href=\"https://www.bing.com\">Bing</a>" +
			"</body>" +
			"</html>";
		
		String tagName = "a";
		RegexUtility regUtil = new SimpleRegexUtil();
		
		String tagContents = regUtil.getHTMLTagContents(html, tagName);
		
		Assert.assertEquals("Bing", tagContents);
	}
	
	@Test
	public void testGetHTMLTagsContents() {
		String html =
			"<!DOCTYPE HTML>\n" +
			"<html>\n" +
			"<body>\n" +
			"<a href=\"https://www.bing.com\">Bing</a>\n" +
			"<a href=\"https://www.duckduckgo.com\">DuckDuckGo</a>\n" +
			"<a href=\"https://www.neumont.edu\">Neumont</a>\n" +
			"</body>\n" +
			"</html>";
		
		String tagName = "a";
		RegexUtility regUtil = new SimpleRegexUtil();
		
		String[] tagsContents = regUtil.getHTMLTagsContents(html, tagName);
		
		Assert.assertEquals("Bing", tagsContents[0]);
		Assert.assertEquals("DuckDuckGo", tagsContents[1]);
		Assert.assertEquals("Neumont", tagsContents[2]);
	}
	
	@Test
	public void testGetHTMLLinkURL() {
		String html =
				"<!DOCTYPE HTML>\n" +
				"<html>\n" +
				"<body>\n" +
				"<a href=\"https://www.bing.com\">Bing</a>\n" +
				"<a href=\"https://www.duckduckgo.com\">DuckDuckGo</a>\n" +
				"<a href=\"https://www.neumont.edu\">Neumont</a>\n" +
				"</body>\n" +
				"</html>";
			
			RegexUtility regUtil = new SimpleRegexUtil();
			
			String[] tagsProps = regUtil.getHTMLLinkURL(html);
			
			Assert.assertEquals("https://www.bing.com", tagsProps[0]);
			Assert.assertEquals("https://www.duckduckgo.com", tagsProps[1]);
			Assert.assertEquals("https://www.neumont.edu", tagsProps[2]);
	}
}
