package edu.neumont.csc180.cox.regexutiltester;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import edu.neumont.csc180.cox.regexutil.RegExLibary;

public class RegExTester {
	
	private static RegExLibary regex;
	
	@BeforeClass
	public static void init() {
		regex = new RegExLibary();
	}
	
	@Test
	public void testValidName() {
		String name = "Nash Molstad";
		boolean result = regex.isValidHumanName(name);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testValidNameWithPrefix() {
		String name = "Mr Nash Molstad";
		boolean result = regex.isValidHumanName(name);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testValidNameWithMiddleInitial() {
		String name = "Nash Q Molstad";
		boolean result = regex.isValidHumanName(name);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testValidNameWithMiddleName() {
		String name = "Nash Quinten Molstad";
		boolean result = regex.isValidHumanName(name);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testValidNameWithPrefixAndMiddleName() {
		String name = "Mister Nash Quinten Molstad";
		boolean result = regex.isValidHumanName(name);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testInvalidName() {
		String name = "nash molstad";
		boolean result = regex.isValidHumanName(name);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testInvalidNameWithNonAlphaCharactes() {
		String name = "Nash Molstad1";
		boolean result = regex.isValidHumanName(name);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testValidEmailAddress() {
		String email = "nmolstad@neumont.edu";
		boolean result = regex.isValidEmailAddress(email);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testValidEmailAddressWithSubDomain() {
		String email = "nmolstad@student.neumont.edu";
		boolean result = regex.isValidEmailAddress(email);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testValidEmailAddressWithDotsAndUnderscores() {
		String email = "n.molstad_boi@neumont.edu";
		boolean result = regex.isValidEmailAddress(email);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testInvalidEmailAddress() {
		String email = "this is not an email";
		boolean result = regex.isValidEmailAddress(email);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testInvalidEmailAddressStartingWithNumber() {
		String email = "123abc@email.com";
		boolean result = regex.isValidEmailAddress(email);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testInvalidEmailAddressShortTopLevelDomain() {
		String email = "abc@email.co";
		boolean result = regex.isValidEmailAddress(email);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testInvalidEmailAddressLongTopLevelDomain() {
		String email = "abc@email.communism";
		boolean result = regex.isValidEmailAddress(email);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testValidPhoneNumber() {
		String phone = "801-867-5309";
		boolean result = regex.isValidPhoneNumber(phone);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testValidPhoneNumberWithCountryCode() {
		String phone = "1-801-867-5309";
		boolean result = regex.isValidPhoneNumber(phone);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testInvalidPhoneNumber() {
		String phone = "not a phone number";
		boolean result = regex.isValidPhoneNumber(phone);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testInvalidPhoneNumberCountryCode() {
		String phone = "0-309-232-1234";
		boolean result = regex.isValidPhoneNumber(phone);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testInvalidPhoneNumberAreaCode() {
		String phone = "109-232-1234";
		boolean result = regex.isValidPhoneNumber(phone);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testValidSSNNumber() {
		String ssn = "126-23-3498";
		boolean result = regex.isValidSSN(ssn);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testInvalidSSNNumber() {
		String ssn = "126-231-3498";
		boolean result = regex.isValidSSN(ssn);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testInvalidSSNNumberAllZeroStart() {
		String ssn = "000-23-3498";
		boolean result = regex.isValidSSN(ssn);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testInvalidSSNNumberAllZeroMiddle() {
		String ssn = "126-00-3498";
		boolean result = regex.isValidSSN(ssn);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testInvalidSSNNumberAllZeroEnd() {
		String ssn = "126-23-0000";
		boolean result = regex.isValidSSN(ssn);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testValidUSStreetAddress() {
		String address = "123 Sesame Street"
				+ "\n Salt Lake City, UT 84104";
		boolean result = regex.isValidUSStreetAddress(address);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testValidUSStreetAddressWithCompassDirection() {
		String address = "123 N Sesame Street"
				+ "\n Salt Lake City, UT 84104";
		boolean result = regex.isValidUSStreetAddress(address);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testValidUSStreetAddressWithUnitNumber() {
		String address = "123 Sesame Street Apt#456"
				+ "\n Salt Lake City, UT 84104";
		boolean result = regex.isValidUSStreetAddress(address);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testValidUSStreetAddressWithoutSpaceAfterCity() {
		String address = "123 Sesame Street"
				+ "\n Salt Lake City,UT 84104";
		boolean result = regex.isValidUSStreetAddress(address);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testValidUSStreetAddressWithZipcodePostfix() {
		String address = "123 Sesame Street"
				+ "\n Salt Lake City, UT 84104-1203";
		boolean result = regex.isValidUSStreetAddress(address);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testInvalidUSStreetAddress() {
		String address = "this is not a us street address";
		boolean result = regex.isValidUSStreetAddress(address);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testInvalidUSStreetAddressWithoutNewLineAfterStreetName() {
		String address = "123 Sesame Street"
				+ " Salt Lake City, UT 84104";
		boolean result = regex.isValidUSStreetAddress(address);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testInvalidUSStreetAddressWithoutCommaAfterCity() {
		String address = "123 Sesame Street"
				+ "\n Salt Lake City UT 84104";
		boolean result = regex.isValidUSStreetAddress(address);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testValidatePasswordComplexityValidPassword() {
		int minLength = 8;
		int minUpper = 1;
		int minLower = 1;
		int minNumeric = 1;
		int minSymbols = 1;
		String password = "Aa!12345";
		boolean result = regex.validatePasswordComplexity(password, minLength, minUpper, minLower, minNumeric, minSymbols);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testValidatePasswordComplexityInvalidPasswordLength() {
		int minLength = 8;
		int minUpper = 1;
		int minLower = 1;
		int minNumeric = 1;
		int minSymbols = 1;
		String password = "Aa!123";
		boolean result = regex.validatePasswordComplexity(password, minLength, minUpper, minLower, minNumeric, minSymbols);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testValidatePasswordComplexityInvalidPasswordUpper() {
		int minLength = 8;
		int minUpper = 1;
		int minLower = 1;
		int minNumeric = 1;
		int minSymbols = 1;
		String password = "ab!12345";
		boolean result = regex.validatePasswordComplexity(password, minLength, minUpper, minLower, minNumeric, minSymbols);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testValidatePasswordComplexityInvalidPasswordLower() {
		int minLength = 8;
		int minUpper = 1;
		int minLower = 1;
		int minNumeric = 1;
		int minSymbols = 1;
		String password = "AB!12345";
		boolean result = regex.validatePasswordComplexity(password, minLength, minUpper, minLower, minNumeric, minSymbols);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testValidatePasswordComplexityInvalidPasswordNumeric() {
		int minLength = 8;
		int minUpper = 1;
		int minLower = 1;
		int minNumeric = 1;
		int minSymbols = 1;
		String password = "Abcdefg!";
		boolean result = regex.validatePasswordComplexity(password, minLength, minUpper, minLower, minNumeric, minSymbols);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testValidatePasswordComplexityInvalidPasswordSymbols() {
		int minLength = 8;
		int minUpper = 1;
		int minLower = 1;
		int minNumeric = 1;
		int minSymbols = 1;
		String password = "Abcdefg1";
		boolean result = regex.validatePasswordComplexity(password, minLength, minUpper, minLower, minNumeric, minSymbols);
		Assert.assertTrue(!result);
	}
	
	@Test
	public void testCountContains() {
		int needleCount = 3;
		int count = regex.countContains("needle", "haystackhaystackhaystackhaystack" + "needle" + "haystackhaystackhaystack" + "needle" + "haystack\nhaystackhaystack" + "needle");
		Assert.assertEquals("Expected: " + needleCount + ", actual: " + count, needleCount, count);
	}
	
	@Test
	public void testGetHTMLTagContentsFirstInstance() {
		String HTML = "<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<body>\r\n" + 
				"\r\n" + 
				"<p>1</p>\r\n" + 
				"<p>2</p>\r\n" + 
				"<p>3</p>\r\n" + 
				"<p>4</p>\r\n" + 
				"<p>5</p>\r\n" + 
				"<p>6</p>\r\n" + 
				"\r\n" + 
				"</body>\r\n" + 
				"</html>";
		String content = regex.getHTMLTagContents(HTML, "p");
		Assert.assertTrue(content.equals("1"));
	}
	
	@Test
	public void testGetHTMLTegContentsAllInstances() {
		String HTML = "<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<body>\r\n" + 
				"\r\n" + 
				"<p>1</p>\r\n" + 
				"<p>2</p>\r\n" + 
				"<p>3</p>\r\n" + 
				"<p>4</p>\r\n" + 
				"<p>5</p>\r\n" + 
				"<p>6</p>\r\n" + 
				"\r\n" + 
				"</body>\r\n" + 
				"</html>";
		String[] contents = regex.getHTMLTagsContents(HTML, "p");
		String[] expectedContents = {"1", "2", "3", "4", "5", "6"};
		Assert.assertEquals("not the same", expectedContents, contents);
	}
	
	@Test
	public void testGetHTMLLinkURL() {
		String HTML = "<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<body>\r\n" + 
				"\r\n" + 
				"<p><a href=\"https://www.google.com\">Google</a></p>\r\n" + 
				"<p><a href=\"https://www.youtube.com\">YouTube</a></p>\r\n" +
				"\r\n" + 
				"</body>\r\n" + 
				"</html>";
		String[] contents = regex.getHTMLLinkURL(HTML);
		String[] expectedContents = {"https://www.google.com", "https://www.youtube.com"};
		Assert.assertEquals("not the same", expectedContents, contents);
	}
}
