package edu.neumont.csc180.cox.regexutil;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExLibary implements RegexUtility {

	public boolean isValidHumanName(String name) {
		final String regex = "((Mr|Ms|Mrs|Dr|Mister|Miss|Misses|Doctor) )?([A-Z][a-z]+)( [A-Z]| [A-Z][a-z]+)? ([A-Z][a-z]+)";
		return name.matches(regex);
	}

	public boolean isValidEmailAddress(String email) {
		final String regex = "((?!\\d)[\\w.]+)@(((?!\\d)\\w+)\\.)?((?!\\d)\\w+)\\.([A-Za-z]{3,4})";
		return email.matches(regex);
	}

	public boolean isValidPhoneNumber(String phone) {
		final String regex = "((?!0)\\d{1,2}-)?([2-9]\\d{2})-([2-9]\\d{2})-(\\d{4})";
		return phone.matches(regex);
	}

	public boolean isValidSSN(String ssn) {
		final String regex = "(^(?!0{3})\\d{3})-((?!0{2})\\d{2})-((?!0{4})\\d{4})";
		return ssn.matches(regex);
	}

	public boolean isValidUSStreetAddress(String street) {
		final String regex = "((?!0)\\d+)( (North|South|East|West|N|S|E|W))? ([A-Za-z0-9 ]+)( (North|South|East|West|N|S|E|W))?( (Apt#|Suite#|#)(?!0)\\d+)?\\n"
				+ "([A-Za-z ]+), ?([A-Z]{2})([ \\n])(\\d{5})(-\\d{4})?";
		return street.matches(regex);
	}

	public boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower,
			int minNumeric, int minSymbols) {
		final String regex = "^(?=.*[a-z]{" + minLower + ",})(?=.*[A-Z]{" + minUpper + ",})(?=.*[0-9]{" + minNumeric + ",})(?=.*[!@#\\$%\\^&\\*]{" + minSymbols + ",})([^\\s]){" + minLength + ",}";
		return password.matches(regex);
	}

	public int countContains(String needle, String haystack) {
		Pattern p = Pattern.compile(needle);
		Matcher m = p.matcher(haystack);
		int count = 0;
		while(m.find()) {
			count++;
		}
		return count;
	}

	public String getHTMLTagContents(String html, String tagName) {
		final String regex = "<" + tagName + "(.*)?>(.*)<\\/" + tagName + ">";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(html);
		while(m.find()) {
			return m.group(2);
		}
		return null;
	}

	public String[] getHTMLTagsContents(String html, String tagName) {
		final String regex = "<" + tagName + "(.*)?>(.*)<\\/" + tagName + ">";
		List<String> contents = new ArrayList<>();
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(html);
		while(m.find()) {
			contents.add(m.group(2));
		}
		String[] tagContents = contents.toArray(new String[contents.size()]);
		return tagContents;
	}

	public String[] getHTMLLinkURL(String html) {
		final String regex = "<a.* href=\"(https:\\/\\/.*?)\".*>.*<\\/a>";
		List<String> contents = new ArrayList<>();
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(html);
		while(m.find()) {
			contents.add(m.group(1));
		}
		String[] tagContents = contents.toArray(new String[contents.size()]);
		return tagContents;
	}

}
