import knapp.braxton.regexexample.RegexMethods;
import org.junit.Assert;
import org.junit.Test;

public class RegexTester {

    @Test
    public void humanNameRegexTester() {
        RegexMethods rm = new RegexMethods();
        String humanName1 = "Mr. John Bruce Jimmy";
        String humanName2 = "Mrs. Helena Jimmy";
        String humanName3 = "Mr. john Jimmy";

        Assert.assertTrue(rm.isValidHumanName(humanName1));
        Assert.assertTrue(rm.isValidHumanName(humanName2));
        Assert.assertFalse(rm.isValidHumanName(humanName3));
    }

    @Test
    public void emailRegexTester() {
        RegexMethods rm = new RegexMethods();
        String email1 = "BonJimmy_John@hotmail.us";
        String email2 = "bbkbbk123@gmail.com";
        String email3 = "Mr. john Jimmy";

        Assert.assertTrue(rm.isValidEmailAddress(email1));
        Assert.assertTrue(rm.isValidEmailAddress(email2));
        Assert.assertFalse(rm.isValidEmailAddress(email3));
    }

    @Test
    public void phoneRegexTester() {
        RegexMethods rm = new RegexMethods();
        String phone1 = "801-505-8446";
        String phone2 = "07-484-838-9999";
        String phone3 = "12345677890";

        Assert.assertTrue(rm.isValidPhoneNumber(phone1));
        Assert.assertTrue(rm.isValidPhoneNumber(phone2));
        Assert.assertFalse(rm.isValidPhoneNumber(phone3));
    }

    @Test
    public void ssnRegexTester(){
        RegexMethods rm = new RegexMethods();
        String ssn1 = "323-71-3046";
        String ssn2 = "123-45-6789";
        String ssn3 = "000-00-0000";

        Assert.assertTrue(rm.isValidSSN(ssn1));
        Assert.assertTrue(rm.isValidSSN(ssn2));
        Assert.assertFalse(rm.isValidSSN(ssn3));
    }

    @Test
    public void usAddressTester(){
        RegexMethods rm = new RegexMethods();
        String usAddress1 = "JANE DOE DOE\n" +
                "COMPANY1 ASSOCIATES HUB\n" +
                "1960 W CHELSEA AVE STE 2006R\n" +
                "NEW YORK NY 84054";
        String usAddress2 = "JANE DOE DOE\n" +
                "COMPANY1 ASSOCIATES HUB\n" +
                "1960 W CHELSEA AVE !STE 2006R\n" +
                "jamesssss SE 54";

        Assert.assertTrue(rm.isValidUSStreetAddress(usAddress1));
        Assert.assertFalse(rm.isValidUSStreetAddress(usAddress2));
    }

    @Test
    public void passwordRegexTester(){
        RegexMethods rm = new RegexMethods();
        String password = "123abc&^%123ABC";

        Assert.assertTrue(rm.validatePasswordComplexity(password, 8,2,2,3,2));
        Assert.assertFalse(rm.validatePasswordComplexity(password, 8,5,5,7,2));
    }

}
