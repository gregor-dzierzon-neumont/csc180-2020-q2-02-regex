package knapp.braxton.regexexample;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexHelper {

    private static final String phoneRegEx = "(\\+[0-9]-)?([0-9]{3})-[0-9]{3}-[0-9]{4}";

    public boolean isValidPhoneNumber(String phone) {
        return phone.matches(phoneRegEx);
    }

    public String getAreaCode(String phone) {
        Pattern p = Pattern.compile(phoneRegEx);
        Matcher m = p.matcher(phone);

        while(m.find()){
            return m.group(2);
//            System.out.println(m.groupCount());
//            for (int i = 0; i < m.groupCount(); i++) {
//                System.out.println("Group " + i + ": " + m.group(i));
//            }
        }
        return null;
    }
    public List<String> findJsonPropNames(String json){
        final String regex = "^\\s*\"(\\w*)\".*$";
        Pattern p = Pattern.compile(regex, Pattern.MULTILINE);
        Matcher m = p.matcher(json);
        List<String> propNames = new ArrayList<>();

        while(m.find()){
            propNames.add(m.group(1));
        }

        return propNames;

    }
}
