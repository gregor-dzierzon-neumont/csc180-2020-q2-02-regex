package knapp.braxton.regexexample;

public class RegexMethods implements RegexUtility {
    private final String humanNameRegex = "^(M[r|s][s]?[.] )?[A-Z][a-z]+ ([A-z]* )?[A-Z][a-z]+";
    private final String emailAddressRegex = "^[A-z]([\\w_\\.])*@[\\w_]+\\.[A-z](\\w{1,3})$";
    private final String phoneRegex = "^([\\d]{0,2}-)?([\\d]{3}-){2}[\\d]{4}";
    private final String ssnRegex = "^(?!666|000)(?!219-09-9999|078-05-1120)[0-8]\\d{2}-\\d[1-9]-(?!0{4})\\d{3}[1-9]$";
    private final String streetAddressRegex = "^[A-Z]+ ([A-Z]* )?([A-Z]+)\\n(([A-Z|0-9]*)+ ([A-Z|0-9]* ?)*)?\\n([A-Z|0-9)]* " +
            ")*[A-Z|0-9)]*\\n([A-Z|0-9)]* ){1,3}(A[LKSZRAP]|C[AOT]|D[EC]|F[LM]|G[AU]|HI|I[ADL N]|K[SY]|LA|M[ADEHINOPST]" +
            "|N[CDEHJMVY]|O[HKR]|P[ARW]|RI|S[CD] |T[NX]|UT|V[AIT]|W[AIVY]) [0-9]{5}";
    private final String countContainsRegex = "";






    @Override
    public boolean isValidHumanName(String name) {
        return name.matches(humanNameRegex);
    }

    @Override
    public boolean isValidEmailAddress(String email) {
        return email.matches(emailAddressRegex);
    }

    @Override
    public boolean isValidPhoneNumber(String phone) {
        return phone.matches(phoneRegex);
    }

    @Override
    public boolean isValidSSN(String ssn) {
        return ssn.matches(ssnRegex);
    }

    @Override
    public boolean isValidUSStreetAddress(String street) {
        return street.matches(streetAddressRegex);
    }

    @Override
    public boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower, int minNumeric, int minSymbols) {
        final String passwordComplexityRegex = "^(?=(?:.*[A-Z]){" + minUpper + ",})" +
                "(?=(?:.*[a-z]){" + minLower + ",})(?=(?:.*\\d){" + minNumeric + ",})" +
                "(?=(?:.*[<.>,:;{}+=_\\-()*&^%$#@!]){" + minSymbols + ",})" +
                "([A-Za-z0-9!@#$%^&*()\\-_=+{};:,<.>]{" + minLength +",})$";
        return password.matches(passwordComplexityRegex);
    }

    @Override
    public int countContains(String needle, String haystack) {
        return 0;
    }

    @Override
    public String getHTMLTagContents(String html, String tagName) {
        return null;
    }

    @Override
    public String[] getHTMLTagsContents(String html, String tagName) {
        return new String[0];
    }

    @Override
    public String[] getHTMLLinkURL(String html) {
        return new String[0];
    }
}
