package knapp.braxton.regexexample;

public class TestDriver {
    public static void main(String[] args) {
        RegexHelper helper = new RegexHelper();
        String phone = "+1-801-867-5309";
        System.out.println(helper.isValidPhoneNumber(phone));
        System.out.println(helper.getAreaCode(phone));
        System.out.println(helper.findJsonPropNames("{\n" +
                "\t\"prop1\":\"val1\",\n" +
                "\t\"prop2\":\"val2\",\n" +
                "\t\"prop3\":\"val3\"\n" +
                "}"));
    }
}
