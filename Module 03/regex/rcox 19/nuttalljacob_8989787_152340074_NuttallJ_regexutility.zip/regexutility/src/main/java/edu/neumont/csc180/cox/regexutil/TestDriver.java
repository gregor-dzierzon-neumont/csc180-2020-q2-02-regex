package edu.neumont.csc180.cox.regexutil;

public class TestDriver {

	public static void main(String[] args) {
		RegexUtil ru = new RegexUtil();
//		System.out.println(ru.getHTMLTagsContents("<p>sjnfks la</p>\r\n" + 
//				"<h1>Hello There!</h1>\r\n" + 
//				"<p>General Kenobi</p>", "p"));

		String[] result = ru.getHTMLTagsContents("<p>sjnfks la</p>\r\n" + 
				"<h1>Hello There!</h1>\r\n" + 
				"<p>General Kenobi</p>", "p");
		System.out.println(result[0]);
		System.out.println(result[1]);
		
//		String[] links = ru.getHTMLLinkURL("<a href=\"https://www.w3schools.com/html/\">Visit our HTML tutorial</a>\r\n" + 
//				"<a href=\"https://stackoverflow.com/questions/49139226/java-how-to-insert-a-hashmap-into-mongodb\">Hello there tehhehe</a>");
//		System.out.println(links[0]);
//		System.out.println(links[1]);
	}

}
