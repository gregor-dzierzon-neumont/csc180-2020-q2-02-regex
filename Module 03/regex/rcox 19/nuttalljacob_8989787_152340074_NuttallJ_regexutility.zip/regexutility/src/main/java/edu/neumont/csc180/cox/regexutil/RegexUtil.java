package edu.neumont.csc180.cox.regexutil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexUtil implements RegexUtility {

	private static final String humanNameRegEx = "([A-Z][a-z]*. )?([A-Z][a-z]* )([A-Z][a-z]* )?([A-Z][a-z]*)";
	private static final String emailRegEx = "([A-Za-z][A-Za-z0-9_.]*)@[A-Za-z][A-Za-z0-9]*.[A-Za-z0-9]{3,4}";
	private static final String phoneRegEx = "([0-9]?[0-9]-)?([0-9]{3})-[0-9]{3}-[0-9]{4}";
	private static final String ssnRegEx = "[0-9]{3}-[0-9]{2}-[0-9]{4}";
	private static final String streetAddressRegEx = "^[0-9]+( [NSWE])?([A-Za-z0-9 ]+)( [NSWE])?( [A-Za-z]*#[0-9]+)?\\n[A-Za-z ]+, [A-Z]{2} [0-9]{5}(-[0-9]{4})?$";

	public boolean isValidHumanName(String name) {
		return name.matches(humanNameRegEx);
	}

	public boolean isValidEmailAddress(String email) {
		return email.matches(emailRegEx);
	}

	public boolean isValidPhoneNumber(String phone) {
		return phone.matches(phoneRegEx);
	}

	public boolean isValidSSN(String ssn) {
		return ssn.matches(ssnRegEx);
	}

	public boolean isValidUSStreetAddress(String street) {
		return street.matches(streetAddressRegEx);
	}

	public boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower,
			int minNumeric, int minSymbols) {
		
//		^(?=.*[A-Z]{1,})(?=.*[a-z]{1,})(?=.*\d{2,})(?=.*[!@#\$%\^&]{0,}).{8,}$
		String passwordRegEx = "^(?=.*[A-Z]{" + minUpper + ",})(?=.*[a-z]{" + minLower + 
				",})(?=.*\\d{" + minNumeric + ",})(?=.*[!@#\\$%\\^&]{" + minSymbols + 
				",}).{" + minLength + ",}$";		
		return password.matches(passwordRegEx);
	}

	public int countContains(String needle, String haystack) {
		String countRegEx = "(" + needle +")";
		Pattern p = Pattern.compile(countRegEx);
		Matcher m = p.matcher(haystack);
		int count = 0;
		
		while(m.find()) {
			count++;
		}
		return count;
	}

	public String getHTMLTagContents(String html, String tagName) {
		final String htmlTagContentRegEx = "<" + tagName + ">([\\w\\s]*)<\\/" + tagName + ">";
		
		Pattern p = Pattern.compile(htmlTagContentRegEx, Pattern.MULTILINE);
		Matcher m = p.matcher(html);

		String result = null;
		while(m.find()) {
			result = m.group(1);
			break;
		}
		return result;
	}

	public String[] getHTMLTagsContents(String html, String tagName) {
		final String htmlTagContentsRegEx = "<" + tagName + ">([\\w\\s]*)<\\/" + tagName + ">";
		
		Pattern p = Pattern.compile(htmlTagContentsRegEx, Pattern.MULTILINE);
		Matcher m = p.matcher(html);
		
		String[] tags = new String[m.groupCount() + 1];
		int count = 0;
		while(m.find()) {
			tags[count] = m.group(1);
			count++;
		}
		return tags;
	}

	public String[] getHTMLLinkURL(String html) {
		final String htmlLinkUrlRegEx = "<a href=\"([!-~]*)\">";
		
		Pattern p = Pattern.compile(htmlLinkUrlRegEx, Pattern.MULTILINE);
		Matcher m = p.matcher(html);
		
		String[] tags = new String[m.groupCount() + 1];
		int count = 0;
		while(m.find()) {
			tags[count] = m.group(1);
			count++;
		}
		return tags;
	}

}
