package nuttall.jacob.regexutility;

import org.junit.Before;
import org.junit.Test;

import edu.neumont.csc180.cox.regexutil.RegexUtil;

public class RegexUtilTester {
	
	RegexUtil ru;
	
	@Before
	public void init() {
		ru = new RegexUtil();
	}

	@Test
	public void testValidNameTrue() {
//		([A-Z][a-z]* )?([A-Z][a-z]* )([A-Z][a-z]* )?([A-Z][a-z]*)
		System.out.println("Jacob Nuttall: " + ru.isValidHumanName("Jacob Nuttall"));
		System.out.println("Jacob W Nuttall: " + ru.isValidHumanName("Jacob W Nuttall"));
		System.out.println("Jacob William Nuttall: " + ru.isValidHumanName("Jacob William Nuttall"));
		System.out.println("Mr. Jacob W Nuttall: " + ru.isValidHumanName("Mr. Jacob W Nuttall"));
		System.out.println("Dr. Jacob Nuttall: " + ru.isValidHumanName("Dr. Jacob Nuttall"));
	}
	
	@Test
	public void testValidNameFalse() {
		System.out.println("jacob: " + ru.isValidHumanName("jacob"));
		System.out.println("jAcob # Nuttall: " + ru.isValidHumanName("jAcob # Nuttall"));
		System.out.println("801-Eat-Cars: " + ru.isValidHumanName("801-Eat-Cars"));
		System.out.println("Walmart: " + ru.isValidHumanName("Walmart"));
		System.out.println("Jacob W Nuttall6: " + ru.isValidHumanName("Jacob W Nuttall6"));
	}
	
	@Test
	public void testValidEmailTrue() {
//	([A-Za-z][A-Za-z0-9_.]*)@[A-Za-z][A-Za-z0-9]*.[A-Za-z0-9]{3,4}
		System.out.println("jacob12vs@gmail.com: " + ru.isValidEmailAddress("jacob12vs@gmail.com"));
		System.out.println("myNameJeff@hotmail.com: " + ru.isValidEmailAddress("myNameJeff@hotmail.com"));
		System.out.println("numbers123@yahoo.org: " + ru.isValidEmailAddress("numbers123@yahoo.org"));
		System.out.println("UnDeRsCrOcE__@ayyy.com: " + ru.isValidEmailAddress("UnDeRsCrOcE__@ayyy.com"));
		System.out.println("hello.There@Kappa123.com: " + ru.isValidEmailAddress("hello.There@Kappa123.com"));
	}
	
	@Test
	public void testValidEmailFalse() {
		System.out.println("2theHunt@gmail.com: " + ru.isValidEmailAddress("2theHunt@gmail.com"));
		System.out.println("Ilikethe$$$@hotmail.com: " + ru.isValidEmailAddress("Ilikethe$$$@hotmail.com"));
		System.out.println("What am I doing?? @ bing.org: " + ru.isValidEmailAddress("What am I doing?? @ bing.org"));
		System.out.println("jacob12vs@yahoo.computer: " + ru.isValidEmailAddress("jacob12vs@yahoo.computer"));
		System.out.println("anythingGoes$gmail.com: " + ru.isValidEmailAddress("anythingGoes$gmail.com"));
	}
	
	@Test
	public void testValidPhoneTrue() {
//		([0-9]?[0-9]-)?([0-9]{3})-[0-9]{3}-[0-9]{4}
		System.out.println("801-726-1156: " + ru.isValidPhoneNumber("801-726-1156"));
		System.out.println("123-456-7890: " + ru.isValidPhoneNumber("123-456-7890"));
		System.out.println("12-345-246-2512: " + ru.isValidPhoneNumber("12-345-246-2512"));
		System.out.println("9-293-384-3049: " + ru.isValidPhoneNumber("9-293-384-3049"));
		System.out.println("341-837-4759:" + ru.isValidPhoneNumber("341-837-4759"));
	}
	
	@Test
	public void testValidPhoneFalse() {
		System.out.println("8017261156: " + ru.isValidPhoneNumber("8017261156"));
		System.out.println("123.456.7890: " + ru.isValidPhoneNumber("123.456.7890"));
		System.out.println("100-234-342-1234: " + ru.isValidPhoneNumber("100-234-342-1234"));
		System.out.println("23-234-2345: " + ru.isValidPhoneNumber("23-234-2345"));
		System.out.println("801-Eat-Cars: " + ru.isValidPhoneNumber("801-Eat-Cars"));
	}
	
	@Test
	public void testValidSSNTrue() {
//		[0-9]{3}-[0-9]{2}-[0-9]{4}
		System.out.println("123-45-6789: " + ru.isValidSSN("123-45-6789"));
		System.out.println("723-35-2941: " + ru.isValidSSN("723-35-2941"));
		System.out.println("093-38-2384: " + ru.isValidSSN("093-38-2384"));
		System.out.println("276-28-4021: " + ru.isValidSSN("276-28-4021"));
		System.out.println("135-24-6978: " + ru.isValidSSN("135-24-6978"));
	}
	
	@Test
	public void testValidSSNFalse() {
		System.out.println("1234-2-345: " + ru.isValidSSN("1234-2-345"));
		System.out.println("1245-23-421: " + ru.isValidSSN("1245-23-421"));
		System.out.println("Social Security Number: " + ru.isValidSSN("Social Security Number"));
		System.out.println("xxx-xx-xxxx: " + ru.isValidSSN("xxx-xx-xxxx"));
		System.out.println("xxx.xx.xxxx: " + ru.isValidSSN("xxx.xx.xxxx"));
	}
	
	@Test
	public void testValidAddressTrue() {
//		[0-9]+ ([NSWE] )?[A-Za-z0-9 ]+( [NSWE])?( [A-Za-z]*#[0-9]+)?\r\n
//		[A-Za-z ]+, ?[A-Z]{2} [0-9]{5}(-[0-9]{4})?
		System.out.println("780 1st Street Ogden, UT 84404: " + ru.isValidUSStreetAddress("780 1st Street\n" + 
				"Ogden, UT 84404"));
		System.out.println(ru.isValidUSStreetAddress("400 W 300 S Manner#334\n" + 
				"San Francisco, CA 84404-3456"));
	}
	
	@Test
	public void testValidAddressFalse() {
		System.out.println(ru.isValidUSStreetAddress("780 1st Street\nOgden, Utah 84404"));
		System.out.println(ru.isValidUSStreetAddress("H@h@ W L0L S @partment\nTimbuktu, Country 42000"));
	}
	
	@Test
	public void testValidPasswordTrue() {
//		(?=.*[A-Z]{" + minUpper + ",})(?=.*[a-z]{" + minLower + 
//		",})(?=.*\\d{" + minNumeric + ",})(?=.*[!@#\\$%\\^&]{" + minSymbols + 
//		",}).{" + minLength + ",}
		System.out.println(ru.validatePasswordComplexity("Password0", 8, 1, 6, 1, 0));
		System.out.println(ru.validatePasswordComplexity("Applemus$c123hehe", 12, 1, 7, 2, 1));
}
	
	@Test
	public void testValidPasswordFalse() {
		System.out.println(ru.validatePasswordComplexity("password", 8, 1, 7, 1, 0));
		System.out.println(ru.validatePasswordComplexity("Passw0rd", 8, 1, 6, 1, 1));
	}
	
	@Test
	public void testCount() {
//		(" + needle +")
		System.out.println("Mississippi - (s->4): " + ru.countContains("s", "Mississippi"));
		System.out.println("How much wood could a wood chuck chuck if a wood chuck could chuck wood - (o-> 11): " + ru.countContains("o", "How much wood could a wood chuck chuck if a wood chuck could chuck wood"));
		System.out.println("Hello - (w->0): " + ru.countContains("w", "Hello"));
		System.out.println("He11o - (1->2): " + ru.countContains("1", "He11o"));
		System.out.println("010100010101001010010101110101001101010 - (0->21): " + ru.countContains("0", "010100010101001010010101110101001101010"));
	}

	@Test
	public void testValidHTML() {
//		<" + tagName + ">([\\w\\s]*)<\\/" + tagName + ">
		System.out.println("Expected - Hello there: " + ru.getHTMLTagContents("<p>Hello there</p>", "p"));
		System.out.println("Expected - General Kenobi: " + ru.getHTMLTagContents("<h1>General Kenobi</h1><h1>I've been expecting you</h1>", "h1"));
		System.out.println("Expected - null: " + ru.getHTMLTagContents("<h1>So uncivilised</h1>", "p"));
	}
	
	@Test
	public void testValidHTMLTags() {
//		<" + tagName + ">([\w\s]*)<\/" + tagName + ">
		String[] tags =  ru.getHTMLTagsContents("<h1>You were my brother Anakin</h1>\r\n"
				+ "<p>I loved you<p>\r\n"
				+ "<h1>I HATE YOU</h1>", "h1");		
		for(String tag : tags) {
			System.out.println(tag);
		}
		
		String[] results = ru.getHTMLTagsContents("<h1>I should not kill you it is not the Jedi way</h1>\r\n" + 
				"<p>Do it</p>\r\n" + 
				"<h1>shwing head chop</h1>", "p");		
		System.out.println(results[0]);
		
	}
	
	@Test
	public void testValidHTMLLink() {
//		<a href=\"([!-~]*)\
		String[] links = ru.getHTMLLinkURL("<a href=\"facebook.com\">Facebook</a>");
		System.out.println(links[0]);
		System.out.println();
		links = ru.getHTMLLinkURL("<a href=\"gmail.com\">Gmail</a><a href=\"google.com\">Google</a>");
		System.out.println(links[0]);
		System.out.println(links[1]);
	}
}
