package regexutility;

import org.junit.Test;

import edu.neumont.csc180.cox.regexutil.UtilImplementation;
import junit.framework.Assert;

public class RegexUtilTest {

	UtilImplementation ui = new UtilImplementation();

	@Test
	public void test_ValidHumanName_Success() {
		String name = "Mr. Joe M. Duck";
		Assert.assertTrue(ui.isValidHumanName(name));
	}

	@Test
	public void testValidName_False() {
		String name = "M jorep";
		Assert.assertFalse(ui.isValidHumanName(name));
	}

	@Test
	public void testValidName_NoPrefix() {
		String name = "Joe M. Duck";
		Assert.assertTrue(ui.isValidHumanName(name));
	}

	@Test
	public void testValidName_FullMiddle() {
		String name = "Joe Meth Duck";
		Assert.assertTrue(ui.isValidHumanName(name));
	}

	@Test
	public void testValidEmail() {
		String email = "this.florgaplap@duck.doo";
		Assert.assertTrue(ui.isValidEmailAddress(email));
	}

	@Test
	public void testInvalidEmail() {
		String email = "o8l_addd***&((@aw2yu3h5'''''.333333333";
		Assert.assertFalse(ui.isValidEmailAddress(email));
	}

	@Test
	public void testEmailSYmbols() {
		String email = "enu*(&(&^*@ducke.foo";
		Assert.assertFalse(ui.isValidEmailAddress(email));
	}

	@Test
	public void testEmailNoAt() {
		String email = "aounbunbininin.feffee.uhdi";
		Assert.assertFalse(ui.isValidEmailAddress(email));
	}

	@Test
	public void testPhoneFull() {
		String phone = "88-223-187-4848";
		Assert.assertTrue(ui.isValidPhoneNumber(phone));
	}

	@Test
	public void testPhoneNoCountry() {
		String phone = "338-282-1988";
		Assert.assertTrue(ui.isValidPhoneNumber(phone));
	}

	@Test
	public void testPhoneAlpha() {
		String phone = "338-aaa-2877";
		Assert.assertFalse(ui.isValidPhoneNumber(phone));
	}

	@Test
	public void testPhoneOneCountry() {
		String phone = "7-223-141-3847";
		Assert.assertTrue(ui.isValidPhoneNumber(phone));
	}

	@Test
	public void testSSN() {
		String ssn = "338-18-8474";
		Assert.assertTrue(ui.isValidSSN(ssn));
	}

	@Test
	public void testSSNAllZero() {
		String ssn = "000-00-0000";
		Assert.assertFalse(ui.isValidSSN(ssn));
	}

	@Test
	public void testSSnAlpha() {
		String ssn = "Afn-33-118t";
		Assert.assertFalse(ui.isValidSSN(ssn));
	}

	@Test
	public void testStreetAddress() {
		String street = "8879 north 1179 south #224\nArizona, SC 88793-1111";
		Assert.assertTrue(ui.isValidUSStreetAddress(street));
	}

	@Test
	public void testAddressShortZip() {
		String street = "8879 north 1179 south #224\nArizona, SC 88793";
		Assert.assertTrue(ui.isValidUSStreetAddress(street));
	}

	@Test
	public void testAddressFail() {
		String street = "Afnt weest fnnf sooth APTTT#fft\nfuntk, ww 88nne";
		Assert.assertFalse(ui.isValidUSStreetAddress(street));
	}

	@Test
	public void testPassword() {
		String password = "Th1sIsP4ssw0rd";
		Assert.assertTrue(ui.validatePasswordComplexity(password, 8, 3, 3, 3, 0));
	}

	@Test
	public void testPasswordNoSymbFail() {
		String password = "Th1sIsP4ssw0rd";
		Assert.assertFalse(ui.validatePasswordComplexity(password, 8, 3, 3, 3, 3));
	}

	@Test
	public void testPasswordAllTHings() {
		String password = "1H@veM4deP@ssw*rd";
		Assert.assertTrue(ui.validatePasswordComplexity(password, 4, 2, 3, 2, 3));
	}

	@Test
	public void testCount() {
		String needle = "far";
		String haystack = "far,fart,farp,larp,carp,afarp";
		Assert.assertEquals(4, ui.countContains(needle, haystack));
	}

	@Test
	public void testCountZeroTime() {
		String needle = "florbak@Test\r\n" + "	public void testPassword() {\r\n"
				+ "		String password = \"Th1sIsP4ssw0rd\";\r\n"
				+ "		Assert.assertTrue(ui.validatePasswordComplexity(password, 8, 3, 3, 3, 0));\r\n" + "	}\r\n"
				+ "	ek";
		String haystack = "henlo";
		Assert.assertEquals(0, ui.countContains(needle, haystack));
	}

	@Test
	public void getHTMLConenst() {
		String html = "<!DOCTYPE html>\r\n" + "<html>\r\n" + "<body>\r\n" + "\r\n" + "<h1>My First Heading</h1>\r\n"
				+ "<p>My first paragraph.</p>\r\n" + "\r\n" + "</body>\r\n" + "</html>";
		String tagName = "p";
		Assert.assertEquals("My first paragraph.", ui.getHTMLTagContents(html, tagName));
	}

	@Test
	public void testHTMLFail() {
		String html = "<!DOCTYPE html>\r\n" + "<html>\r\n" + "<body>\r\n" + "\r\n" + "<h1>My First Heading</h1>\r\n"
				+ "<p>My first paragraph.</p>\r\n" + "\r\n" + "</body>\r\n" + "</html>";
		String tagName = "htue";
		Assert.assertEquals(null, ui.getHTMLTagContents(html, tagName));
	}

	@Test
	public void testHtmlArray() {
		String html = "<!DOCTYPE html>\r\n" + "<html>\r\n" + "<body>\r\n" + "\r\n" + "<h1>My First Heading</h1>\r\n"
				+ "<p>My first paragraph.</p>\r\n<p>My first paragraph.</p>\r\n<p>My first paragraph.</p>\r\n" + "\r\n"
				+ "</body>\r\n" + "</html>";
		String tagName = "p";
		String[] s = new String[] { "My first paragraph.", "My first paragraph.", "My first paragraph." };
		Assert.assertEquals(s, ui.getHTMLTagsContents(html, tagName));
	}

	@Test
	public void getHTMLLihnk() {
		String html = "<!DOCTYPE html>\r\n" + "<html>\r\n" + "<body>\r\n" + "\r\n" + "<h1>My First Heading</h1>\r\n"
				+ "<p>My first paragraph.</p>\r\n<p>My first paragraph.</p>\\r\\n<p>My first paragraph.</p>\\r\\n"
				+ "\r\n" + "<a href=\"w.com\"></a><a href=\"google.net\"></a><a href=\"flap.duck\"></a>" + "</body>\r\n"
				+ "</html>";
		String[] s = new String[] { "w.com", "google.net", "flap.duck" };
		Assert.assertEquals(s, ui.getHTMLLinkURL(html));

	}

}
