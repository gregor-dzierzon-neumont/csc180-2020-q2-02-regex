package edu.neumont.csc180.cox.regexutil;

public class Thing {

	public static void main(String[] args) {
		UtilImplementation ui = new UtilImplementation();
		String s = ui.getHTMLTagContents("<!DOCTYPE html>\r\n" + "<html>\r\n" + "<body>\r\n" + "\r\n"
				+ "<h1>My First Heading</h1>\r\n"
				+ "<p>My first paragraph.</p>\r\n<p>My first paragraph.</p>\\r\\n<p>My first paragraph.</p>\\r\\n"
				+ "\r\n" + "</body>\r\n" + "</html>", "p");
		System.out.println(s);
		ui.getHTMLLinkURL("<!DOCTYPE html>\r\n" + "<html>\r\n" + "<body>\r\n" + "\r\n" + "<h1>My First Heading</h1>\r\n"
				+ "<p>My first paragraph.</p>\r\n<p>My first paragraph.</p>\\r\\n<p>My first paragraph.</p>\\r\\n"
				+ "\r\n" + "<a href=\"w.com\"></a><a href=\"google.net\"></a><a href=\"flap.duck\"></a>" + "</body>\r\n"
				+ "</html>");
	}

}
