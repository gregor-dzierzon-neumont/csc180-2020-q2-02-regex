package edu.neumont.csc180.cox.regexutil;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UtilImplementation implements RegexUtility {

	@Override
	public boolean isValidHumanName(String name) {
		return Pattern.matches(
				"(Mr\\. |Ms\\. |Miss |Mrs\\. |Dr\\. )?([A-Z][a-z]+)( [A-Z]\\.?| [A-Z][a-z]+)?( [A-Z][a-z]+)?", name);
	}

	@Override
	public boolean isValidEmailAddress(String email) {
		return Pattern.matches("([[:alpha:]]|\\w|\\.)+@[[:alpha:]]([[:alnum:]])+\\.[[:alnum:]]{3,4}", email);
	}

	@Override
	public boolean isValidPhoneNumber(String phone) {
		return Pattern.matches("([\\d]{1,2}-)?[\\d]{3}-[\\d]{3}-[\\d]{4}", phone);
	}

	@Override
	public boolean isValidSSN(String ssn) {
		return Pattern.matches(
				"(\\d\\d[1-9]|\\d[1-9]\\d|[1-9]\\d\\d)-(\\d[1-9]|[1-9]\\d)-(\\d\\d\\d[1-9]|\\d\\d[1-9]\\d|\\d[1-9]\\d\\d|[1-9]\\d\\d\\d)",
				ssn);
	}

	@Override
	public boolean isValidUSStreetAddress(String street) {
		return Pattern.matches(
				"\\d+ ([Nn]orth|[Ss]outh|[Ee]ast|[Ww]est) [a-zA-Z0-9| ]+ ([Nn]orth|[Ss]outh|[Ee]ast|[Ww]est) (Apt#|Suite#|#)\\d+\\n[a-zA-Z| ]+\\, [A-Z]{2}[\\n| ]\\d{5}(-\\d{4})?",
				street);
	}

	@Override
	public boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower,
			int minNumeric, int minSymbols) {

		return Pattern.matches(".{" + minLength + ",}", password)
				&& Pattern.matches("^(?:[^A-Z]*+[A-Z]){" + minUpper + ",}[^A-Z]*+$", password)
				&& Pattern.matches("^(?:[^a-z]*+[a-z]){" + minLower + ",}[^a-z]*+$", password)
				&& Pattern.matches("^(?:[^\\d]*+[\\d]){" + minNumeric + ",}[^\\d]*+$", password)
				&& Pattern.matches("^(?:[^\\W|_]*+[\\W|_]){" + minSymbols + ",}[^\\W|_]*+$", password);
	}

	@Override
	public int countContains(String needle, String haystack) {
		return haystack.split(Pattern.quote(needle), -1).length - 1;
	}

	@Override
	public String getHTMLTagContents(String html, String tagName) {
		Matcher m = Pattern.compile(".*<" + tagName + ">(.*)?<\\\\/" + tagName + ">.*").matcher(html);
		return m.find() ? m.group(1) : null;
	}

	@Override
	public String[] getHTMLTagsContents(String html, String tagName) {
		Matcher m = Pattern.compile(".*<" + tagName + ">(.*)?<\\/" + tagName + ">.*").matcher(html);
		List<String> ls = new ArrayList<>();

		while (m.find())
			ls.add(m.group(1));
		String[] s = new String[ls.size()];
		for (int i = 0; i < s.length; i++)
			s[i] = ls.get(i);
		return s;
	}

	@Override
	public String[] getHTMLLinkURL(String html) {
		Matcher m = Pattern.compile(".*<a href=\"(([^\\r\\n])*)\"><\\/a>.*").matcher(html);
		List<String> ls = new ArrayList<>();
		while (m.find())
			ls.add(m.group(1));
		String[] s = new String[ls.size()];
		for (int i = 0; i < s.length; i++)
			s[i] = ls.get(i);
		return s;
	}

}
