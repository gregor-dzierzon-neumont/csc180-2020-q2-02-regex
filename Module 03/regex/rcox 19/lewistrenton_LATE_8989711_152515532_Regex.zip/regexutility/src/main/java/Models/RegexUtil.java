package Models;

import java.util.ArrayList;
import java.util.List;

import edu.neumont.csc180.cox.regexutil.RegexUtility;

public class RegexUtil implements RegexUtility {

	public boolean isValidHumanName(String name) {

		return name.matches(
				"(Mr(\\.|\\s)|Miss(\\.|\\s)|Ms(\\.|\\s)|Mrs(\\.|\\s)|Dr(\\.|\\s))?[A-Z][a-z]+\\s([A-Z]|[A-Z][a-z]*(\\.)?\\s)?[A-Z][a-z]+");
	}

	public boolean isValidEmailAddress(String email) {
		// TODO Auto-generated method stub
		return email.matches("([a-zA-Z0-9\\.\\_]+)+\\@[a-zA-Z]+\\.([a-zA-Z]+\\.)?[a-zA-Z]+");
	}

	public boolean isValidPhoneNumber(String phone) {
		// TODO Auto-generated method stub
		return phone.matches("([1-9]\\-|[0-9]{2}\\-)?([2-9][0-9]{2})\\-([2-9][0-9]{2})\\-([0-9]{4})");
	}

	public boolean isValidSSN(String ssn) {
		boolean matches = false;
		if (ssn.matches("[0-8][0-9]{2}\\-[0-9]{2}\\-[0-9]{4}")) {
			String[] parts = ssn.split("-");
			if (parts[0].contains("000") || parts[0].contains("666")) {
				matches = false;
			} else if (parts[1].contains("00")) {
				matches = false;
			} else if (parts[2].contains("0000")) {
				matches = false;
			} else {
				matches = true;
			}
		}
		return matches;
	}

	public boolean isValidUSStreetAddress(String street) {
		// TODO Auto-generated method stub
		return street.matches("\\d+\\s(north\\s|south\\s|east\\s|west\\s|North\\s|South\\s|East\\s|West\\s)?"
				+ "[\\w ]+(north\\s|south\\s|east\\s|west\\s|North\\s|South\\s|East\\s|West\\s)?(Apt#[0-9]+|Suite#[0-9]+|#[0-9]+)?"
				+ "\\n[\\w ]+\\,\\s[A-Z]{2}(\\n|\\s)\\d{5}(\\-\\d{4})?");
	}

	public boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower,
			int minNumeric, int minSymbols) {
		boolean valid = false;
		int numOfUpper = 0;
		int numOfLower = 0;
		int numOfNumerals = 0;
		int numOfSymbols = 0;
		if (password.length() >= minLength) {
			char[] charsOfPassword = password.toCharArray();
			for (char c : charsOfPassword) {
				if ((c + "").matches("[A-Z]")) {
					numOfUpper++;
				} else if ((c + "").matches("[a-z]")) {
					numOfLower++;
				} else if ((c + "").matches("[0-9]")) {
					numOfNumerals++;
				} else if ((c + "").matches("[\\W]")) {
					numOfSymbols++;
				}
			}
			if (numOfUpper >= minUpper && numOfLower >= minLower && numOfNumerals >= minNumeric
					&& numOfSymbols >= minSymbols) {
				valid = true;
			}
		}

		return valid;
	}

	public int countContains(String needle, String haystack) {
		int i = 0;
		if (needle.length() > 1) {
			String[] s = haystack.split(needle);
			i = s.length;
			if (haystack.endsWith(needle)) {
				i++;
			}
		} else if (needle.length() == 1) {
			char[] charsOfHaystack = haystack.toCharArray();
			for (char c : charsOfHaystack) {
				if ((c + "").matches(needle)) {
					i++;
				}
			}
		}
		return i;
	}

	public String getHTMLTagContents(String html, String tagName) {
		String result = "";
		String temp = "";
		String[] parts = html.split("<" + tagName + ">");
		for (int i = 0; i < parts.length; i++) {
			if (parts[i].equals("")) {
				temp += parts[i].replace(parts[i], "<" + tagName + ">");
			} else if (!parts[i].equals("")) {
				if (i == 0) {

				} else {
					temp += (parts[i].substring(0, parts[i].length() - (tagName.length() + 3)));
				}
			}
		}
		result = temp.substring(html.indexOf("<" + tagName + ">") + 5);
		return result;
	}

	public String[] getHTMLTagsContents(String html, String tagName) {
		String[] parts = html.split("<(\\/)?" + tagName + ">");
		String[] results = new String[parts.length - 1];
		int resultsCounter = 0;

		for (int i = 0; i < parts.length; i++) {
			if (!parts[i].equals("")) {
				results[resultsCounter] = parts[i];
				resultsCounter++;
			}
		}
		return results;
	}

	public String[] getHTMLLinkURL(String html) {
		String[] parts = html.split("<a href=\"");
		String[] results = new String[parts.length - 1];
		int resultsCounter = 0;

		for (int i = 0; i < parts.length; i++) {
			if (!parts[i].equals("")) {
				results[resultsCounter] = parts[i].substring(0, parts[i].length() - 6);
				resultsCounter++;
			}
		}
		return results;
	}

}
