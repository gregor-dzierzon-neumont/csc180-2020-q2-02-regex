package tester;

import org.junit.BeforeClass;
import org.junit.Test;

import Models.RegexUtil;
import junit.framework.Assert;

public class RegexTester {

	private static RegexUtil ru;

	@BeforeClass
	public static void init() {
		ru = new RegexUtil();
	}

	@SuppressWarnings("deprecation")
	@Test
	public void isValidName() {
		Assert.assertEquals(true, ru.isValidHumanName("Mr.Trenton J. Lewis"));
		Assert.assertEquals(true, ru.isValidHumanName("Mr Trenton J Lewis"));
		Assert.assertEquals(true, ru.isValidHumanName("Miss May Parker"));
		Assert.assertEquals(false, ru.isValidHumanName("bruce wayne"));

	}

	@SuppressWarnings("deprecation")
	@Test
	public void isValidPhoneNumber() {
		Assert.assertEquals(true, ru.isValidPhoneNumber("77-702-250-6198"));
		Assert.assertEquals(true, ru.isValidPhoneNumber("1-702-250-6198"));
		Assert.assertEquals(true, ru.isValidPhoneNumber("702-250-6198"));
		Assert.assertEquals(false, ru.isValidPhoneNumber("377-702-250-6198"));

	}

	@SuppressWarnings("deprecation")
	@Test
	public void isValidEmail() {
		Assert.assertEquals(true, ru.isValidEmailAddress("tj.lewis1025@gmail.com"));
		Assert.assertEquals(true, ru.isValidEmailAddress("tjlewis@gmail.com"));
		Assert.assertEquals(true, ru.isValidEmailAddress("tj_lewis1025@gmail.com"));
		Assert.assertEquals(false, ru.isValidEmailAddress("tj#lewis1025@gmail.com"));

	}

	@SuppressWarnings("deprecation")
	@Test
	public void isValidSSN() {
		Assert.assertEquals(true, ru.isValidSSN("123-45-6789"));
		Assert.assertEquals(false, ru.isValidSSN("000-45-6789"));
		Assert.assertEquals(false, ru.isValidSSN("123-00-6789"));
		Assert.assertEquals(false, ru.isValidSSN("123-45-0000"));
		Assert.assertEquals(false, ru.isValidSSN("666-45-6789"));
		Assert.assertEquals(false, ru.isValidSSN("900-45-6789"));
	}

	@SuppressWarnings("deprecation")
	@Test
	public void isValidAddress() {
		Assert.assertEquals(true,
				ru.isValidUSStreetAddress("920 Gary Carmena Avenue \n" + "North Las Vegas, NV\n" + "89081-1234"));
		Assert.assertEquals(true, ru.isValidUSStreetAddress("343 south 500 east #420\n" + "Salt Lake City, UT 84102"));
	}

	@SuppressWarnings("deprecation")
	@Test
	public void isValidPassword() {
		Assert.assertEquals(true, ru.validatePasswordComplexity("123Password!", 12, 1, 7, 3, 1));

	}

	@SuppressWarnings("deprecation")
	@Test
	public void countContains() {
		Assert.assertEquals(2, ru.countContains("p", "apple"));
	}

	@Test
	public void getFirstHTMLTag() {
		System.out.println(ru.getHTMLTagContents("<div><div><div>text</div></div></div>", "div"));
	}
	
	@Test
	public void getAllTags() {
		String[] parts = ru.getHTMLTagsContents("<div>yes<div>no<div>text</div>hi</div>bye</div>", "div");
		for (String string : parts) {
			System.out.println(string);
		}
	}
	
	@Test
	public void getHrefs() {
		String[] parts = ru.getHTMLLinkURL("<a href=\"youtube.com\"></a><a href=\"lms.com\"></a>");
		for (String string : parts) {
			System.out.println(string);
		}
	}

}
