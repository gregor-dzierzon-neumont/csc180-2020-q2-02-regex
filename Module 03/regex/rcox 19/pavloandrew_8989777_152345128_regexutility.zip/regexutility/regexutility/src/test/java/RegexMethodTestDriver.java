import edu.neumont.csc180.cox.regexutil.RegexMethods;
import org.junit.Test;
import org.junit.Assert;

public class RegexMethodTestDriver {

    RegexMethods rm = new RegexMethods();

    @Test
    public void humanNameTest() {
        Assert.assertEquals(true, rm.isValidHumanName("Andrew"));
    }

    @Test
    public void emailTest() {
        Assert.assertEquals(true, rm.isValidEmailAddress("uipa@gmail.com"));
    }

    @Test
    public void phoneTest() {
        Assert.assertEquals(true, rm.isValidPhoneNumber("321-432-0093"));
        Assert.assertEquals(true, rm.isValidPhoneNumber("1-321-999-0832"));
    }

    @Test
    public void ssnTest() {
        Assert.assertEquals(true, rm.isValidSSN("893-09-9832"));
    }

    @Test
    public void addressTest() {
        Assert.assertEquals(true, "1459 North Lous Street West #89 Salt Lake , UT 89873");
    }

    @Test
    public void passwordTest() {
        Assert.assertEquals(true, rm.validatePasswordComplexity("4543akpe-I", 4, 1, 1, 1, 1));
    }

    @Test
    public void countTest() {
        Assert.assertEquals(true, rm.countContains("a", "hello address book"));
    }

    @Test
    public void HTMLTest() {
        Assert.assertEquals("test", rm.getHTMLTagContents("<html>test</html>", "html"));
    }
}
