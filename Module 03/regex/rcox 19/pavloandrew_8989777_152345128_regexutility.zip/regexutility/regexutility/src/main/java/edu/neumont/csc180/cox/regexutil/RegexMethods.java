package edu.neumont.csc180.cox.regexutil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexMethods implements RegexUtility {

    public boolean isValidHumanName(String name) {
        String nameRegEx = "([A-Z][a-z]*[.])|[A-Z][a-z]*\\s[A-Z][a-z]*\\s[A-Z][a-z]*";
        return name.matches(nameRegEx);
    }

    public boolean isValidEmailAddress(String email) {
        String emailRegEx = "[A-Z]|[a-z][A-Za-z.0-9]*[@][a-z]*[.][a-z]*";
        return email.matches(emailRegEx);
    }

    public boolean isValidPhoneNumber(String phone) {
        String phoneRegEx = "([0-9]-|[0-9]{2}-)?([0-9]{3})-[0-9]{3}-[0-9]{4}";

        return phone.matches(phoneRegEx);
    }

    public boolean isValidSSN(String ssn) {
        String ssnRegEx = "^(?!000)(?!666)(?!9)\\d{3}([- ]?)(?!00)\\d{2}\\1(?!0000)\\d{4}$";
        return ssn.matches(ssnRegEx);
    }

    public boolean isValidUSStreetAddress(String street) {
        String streetAddress = "[0-9]*\\\\s[A-z]*\\\\s\\\\w*\\\\s[A-z]*\\\\s([AptSuite#]*|[#])[0-9]*\\\\s([A-z]*\\\\s)*" +
                "[,]\\\\s[A-Z]{2}\\\\s\" +\n\"([0-9]{5}|[0-9]{5}[-][0-9]{4})";
        return street.matches(streetAddress);
    }

    public boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower, int minNumeric, int minSymbols) {

        String passwordRegEx = "^(?:(?=.{"+ minLower+ ",}[a-z])(?:(?=.{" + minUpper +",}[A-Z])(?=.{"+ minSymbols +",}[\\d\\W])|" +
                "(?=.{" + minSymbols + ",}\\W)(?=.{" + minNumeric + ",}\\d))|(?=.*\\W)(?=.{" + minUpper + ",}[A-Z])" +
                "(?=." + minNumeric+ "\\d)).{" + minLength+ ",}$";
        return password.matches(passwordRegEx);
    }

    public int countContains(String needle, String haystack) {
        int count = 0;
        Pattern p = Pattern.compile(needle);
        Matcher m = p.matcher(haystack);

        while(m.find()) {
            count++;
        }

        return count;
    }

    public String getHTMLTagContents(String html, String tagName) {
        String tagContentsTag = "(?s)(?<=\\<"+tagName+">)(.*?)(?=\\<\\/"+tagName+"\\>)";
        Pattern p = Pattern.compile(tagContentsTag);
        Matcher m = p.matcher(html);

        return m.toString();
    }

    public String[] getHTMLTagsContents(String html, String tagName) {
        return new String[0];
    }

    public String[] getHTMLLinkURL(String html) {
        return new String[0];
    }
}
