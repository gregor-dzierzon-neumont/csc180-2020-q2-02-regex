package regexutility;

import org.junit.Assert;
import org.junit.Test;

import edu.neumont.csc180.cox.regexutil.RegexUser;

public class Tests {

	@Test
	public void testHumanName() {
		RegexUser ru = new RegexUser();
		String validName = "Mr. Lucas Frizzell";
		String invalidName = "Zorgack of Planet 33";

		boolean validIsValid = ru.isValidHumanName(validName);
		boolean invalidIsInvalid = !ru.isValidHumanName(invalidName);

		boolean isCorrect = validIsValid && invalidIsInvalid;

		Assert.assertTrue(isCorrect);
	}

	@Test
	public void testEmail() {
		RegexUser ru = new RegexUser();
		String validEmail = "lucasmcmanus21@gmail.com";
		String invalidEmail = "12kf";

		boolean validIsValid = ru.isValidEmailAddress(validEmail);
		boolean invalidIsInvalid = !ru.isValidEmailAddress(invalidEmail);

		boolean isCorrect = validIsValid && invalidIsInvalid;

		Assert.assertTrue(isCorrect);
	}

	@Test
	public void testValidSSN() {
		RegexUser ru = new RegexUser();
		String validSsn = "020-45-9874";
		String invalidSsn = "666-54-4514";

		boolean validIsValid = ru.isValidSSN(validSsn);
		boolean invalidIsInvalid = !ru.isValidSSN(invalidSsn);

		boolean isCorrect = validIsValid && invalidIsInvalid;

		Assert.assertTrue(isCorrect);
	}

	@Test
	public void testValidStreetAddress() {
		RegexUser ru = new RegexUser();
		String validStreet = "180 W State St Apt#30\n" + "Salt Lake City, UT 84111";

		String invalidStreet = "56 Forest St Carver Ma";

		boolean validIsValid = ru.isValidUSStreetAddress(validStreet);
		boolean invalidIsInvalid = !ru.isValidUSStreetAddress(invalidStreet);

		boolean isCorrect = validIsValid && invalidIsInvalid;

		Assert.assertTrue(isCorrect);
	}

	@Test
	public void testCountContains() {
		RegexUser ru = new RegexUser();
		String myWealth = "poor";
		String billGatesWealth = "rich";

		boolean validIsValid = ru.countContains("o", myWealth) == 2;
		boolean invalidIsInvalid = !(ru.countContains("c", billGatesWealth) != 1);

		boolean isCorrect = validIsValid && invalidIsInvalid;

		Assert.assertTrue(isCorrect);

	}

	@Test
	public void testPasswordComplexity() {
		RegexUser ru = new RegexUser();

		boolean validIsValid = ru.validatePasswordComplexity("Lukato123", 5, 1, 3, 3, 0);
		boolean invalidIsInvalid = !ru.validatePasswordComplexity("Lukato123", 3, 1, 2, 4, 4);

		boolean isCorrect = validIsValid && invalidIsInvalid;

		Assert.assertTrue(isCorrect);

	}

}
