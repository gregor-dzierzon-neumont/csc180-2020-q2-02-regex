package edu.neumont.csc180.cox.regexutil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexUser implements RegexUtility {

	public boolean isValidHumanName(String name) {
		String regex = "([A-Z]{1}[a-z]*\\.\\s{1})?[A-Z]{1}[a-z]*\\s{1}([A-Z]{1}[A-Za-z]*\\s{1})?[A-Z]{1}[a-zA-z]*";

		return name.matches(regex);
	}

	public boolean isValidEmailAddress(String email) {
		String regex = "[A-Za-z]{1}[A-z0-9]*@[a-z]*.[a-z]*";
		return email.matches(regex);
	}

	public boolean isValidPhoneNumber(String phone) {
		String regex = "(\\+[0-9]{1,2}-)?([0-9]{3})-[0-9]{3}-[0-9]{4}";
		return phone.matches(regex);
	}

	public boolean isValidSSN(String ssn) {
		String regex = "^(?!078-05-1120|219-09-999)(?!666|000|9)\\d{3}-(?!00)\\d{2}-(?!000)\\d{4}$";
		return ssn.matches(regex);
	}

	public boolean isValidUSStreetAddress(String street) {
		String regex = "[0-9]+(\\s{1}[N|S|E|W])?\\s{1}[\\w\\s]*(\\s{1}[N|S|E|W])?(\\s{1}APT#[\\d]+ |Suite#[\\d]+|#[\\d]+)?\\n([A-Za-z\\s])*,(\\s)?[A-Z]{2}(\\n)?(\\s)?[\\d]{5}"
				+ "";
		return street.matches(regex);
	}

	public int countContains(String needle, String haystack) {

		int count = 0;

		Pattern pattern = Pattern.compile(needle);
		Matcher matcher = pattern.matcher(haystack);
		while (matcher.find()) {
			count++;
		}

		return count;
	}

	public boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower,
			int minNumeric, int minSymbols) {
		boolean isValid = false;
		int foundNumeric = 0, foundSymbols = 0, foundUpper = 0, foundLower = 0;

		if (password.length() >= minLength) {
			for (int i = 0; i < password.length(); i++) {
				if (Character.isDigit(password.charAt(i))) {
					foundNumeric++;
				} else if (Character.isLowerCase(password.charAt(i))) {
					foundLower++;
				} else if (Character.isUpperCase(password.charAt(i))) {
					foundUpper++;
				} else if (!Character.isSpaceChar(password.charAt(i))) {
					foundSymbols++;
				}
			}
			if (foundNumeric >= minNumeric && foundSymbols >= minSymbols && foundUpper >= minUpper
					&& foundLower >= minLower) {
				isValid = true;
			}
		}

		return isValid;
	}

	public String getHTMLTagContents(String html, String tagName) {
		// TODO Auto-generated method stub
		return null;
	}

	public String[] getHTMLTagsContents(String html, String tagName) {
		// TODO Auto-generated method stub
		return null;
	}

	public String[] getHTMLLinkURL(String html) {
		// TODO Auto-generated method stub
		return null;
	}

}
