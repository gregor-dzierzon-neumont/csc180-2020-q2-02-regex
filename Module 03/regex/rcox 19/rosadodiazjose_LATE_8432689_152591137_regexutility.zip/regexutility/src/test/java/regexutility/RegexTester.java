package regexutility;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.neumont.csc180.cox.regexutil.RegexUtilityClass;

public class RegexTester {

	RegexUtilityClass rg = new RegexUtilityClass();
	
	@Test
	public void isHumanNameValidTest() {
		assertTrue(rg.isValidHumanName("Jose"));
		assertTrue(rg.isValidHumanName("Jose Luis"));
		assertTrue(rg.isValidHumanName("Jose L Rosado"));
		assertTrue(rg.isValidHumanName("Mr Rosado"));
		assertFalse(rg.isValidHumanName("Jo$e 1"));
	}
	
	@Test
	public void isValidEmailAddressTest() {
		assertTrue(rg.isValidEmailAddress("test@here.now"));
		assertTrue(rg.isValidEmailAddress("teSt@here.now"));
		assertTrue(rg.isValidEmailAddress("test_mail@here.now"));
		assertTrue(rg.isValidEmailAddress("test.mail@here.now"));
		assertFalse(rg.isValidEmailAddress("1test@here.now"));
		assertFalse(rg.isValidEmailAddress("test@1here.now"));
		assertFalse(rg.isValidEmailAddress("t[est]@here.now"));
	}
	
	@Test
	public void isValidPhoneNumberTest() {
		assertTrue(rg.isValidPhoneNumber("888-222-1234"));
		assertTrue(rg.isValidPhoneNumber("1-888-222-1234"));
		assertTrue(rg.isValidPhoneNumber("49-888-222-1234"));
		assertFalse(rg.isValidPhoneNumber("ksj-2828-k"));
	}
	
	@Test
	public void isValidSSNTest() {
		assertTrue(rg.isValidSSN("123-45-6778"));
		assertFalse(rg.isValidSSN("000-00-0000"));
		assertFalse(rg.isValidSSN("123-00-0000"));
	}
	
	@Test
	public void isValidUSStreetAddressTest() {
		assertTrue(rg.isValidUSStreetAddress(
				"123 North Whoopi West Apt#1\r\n" + 
				"City Name, UT\r\n" + 
				"12345-1234"));
		assertTrue(rg.isValidUSStreetAddress(
				"123 South 456 East Suite#420\r\n" + 
				"City Name, TX 12345-1234"));
	}
	
	@Test
	public void validatPasswordComplexityTest() {
		assertTrue(rg.validatePasswordComplexity("password", 6, 0, 0, 0, 0));
		assertTrue(rg.validatePasswordComplexity("pass.Word1", 2, 1, 1, 1, 1));
		assertFalse(rg.validatePasswordComplexity("PASS12word??", 500, 20, 20, 20, 20));
	}
	
	@Test
	public void countContainsTest() {
		String s = "haystackneedle";
		int actual = rg.countContains("needle", s);
		
		int expected = 1;
		
		assertEquals(expected, actual);
	}
	
	@Test
	public void getHTMLTagContentsTest() {
		String tag = "<a href=\"review.html\">Home</a>";
		
		String actual = rg.getHTMLTagContents(tag,"a");
		String expected = "Home";
		
		assertEquals(expected, actual);
	}
	
	@Test
	public void getHTMLTagsContentsTest() {
		String tag = "<b>hello</b><c>eep</c>\n<b>hi</b>";
		
		String[] expected = new String[2];
		expected[0] = "hello";
		expected[1] = "hi";
		
		String[] actual = rg.getHTMLTagsContents(tag, "b");
		
		assertArrayEquals(expected, actual);
	}
	
	@Test
	public void getHTMLLinkURLTest() {
		String[] expected = new String[3];
		
		expected[0] = "wow";
		expected[1] = "nope";
		expected[2] = "whoop";
		
		String tags = "<a href=\"wow\"></a>\n<a href=\"nope\">home</a>"
				+ "<a href=\"whoop\">wok wok</a>";
		
		String[] actual = rg.getHTMLLinkURL(tags);
		
		assertArrayEquals(expected, actual);
	}

}
