package edu.neumont.csc180.cox.regexutil;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexUtilityClass implements RegexUtility {

	public boolean isValidHumanName(String name) {
		String regex = "([A-Za-z]{1}[A-Za-z]*)(\\s[A-Z]{1}[A-Za-z]*)?(\\s[A-Z]{1}[A-Za-z]*)?";
		return name.matches(regex);
	}

	public boolean isValidEmailAddress(String email) {
		String regex = "[A-Za-z][A-Za-z0-9_.]*@[A-Za-z][A-Za-z0-9]*.[A-Za-z]*";
		return email.matches(regex);
	}

	public boolean isValidPhoneNumber(String phone) {
		String regex = "((\\+?[0-9]-)|(\\+?[0-9]{2}-))?([0-9]{3})-[0-9]{3}-[0-9]{4}";
		return phone.matches(regex);
	}

	public boolean isValidSSN(String ssn) {
		String regex = "([0-8][0-9]{2})-([0-9]{2})-([0-9]{4})";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(ssn);
		
		while(m.find()) {
			if(m.group(1) == "000" || m.group(1).equals("666") || m.group(2).equals("00") || m.group(3).equals("0000")) {
			return false;
			}
		}
		return true;
	}

	public boolean isValidUSStreetAddress(String street) {
		String regex = 
				"([0-9]+) ([North|South|East|West]+) (.*|[0-9]+) ([North|South|East|West]+)(\\s+?)(\\w+#[0-9]+)?(\\s+?)(.*,)"
				+ " ([A-Z]{2})(\\s+?)([0-9]{5}(-[0-9]{4})?)";
		return street.matches(regex);
	}

	public boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower,
			int minNumeric, int minSymbols) {
		String upperCaseCheck = "[A-Z]";
		String lowerCaseCheck = "[a-z]";
		String numericCheck = "[0-9]";
		
		Pattern p = Pattern.compile(lowerCaseCheck);
		Matcher m = p.matcher(password);

		int lowerCount = 0;
		while(m.find()) {
			lowerCount++;
		}
		
		p = Pattern.compile(upperCaseCheck);
		m = p.matcher(password);
		int upperCount = 0;
		while(m.find()) {
			upperCount++;
		}
		
		p = Pattern.compile(numericCheck);
		m = p.matcher(password);
		int numCount = 0;
		while(m.find()) {
			numCount++;
		}
		
		int symbolCount = password.length() - lowerCount - upperCount - numCount;
		
		if(password.length() >= minLength && 
				upperCount >= minUpper && lowerCount >= minLower
				&& numCount >= minNumeric && symbolCount >= minSymbols) {
			return true;
		}
		
		return false;
	}

	public int countContains(String needle, String haystack) {
		Pattern p = Pattern.compile(needle);
		Matcher m = p.matcher(haystack);
		int count = 0;
		while(m.find()) {
			count++;
		}
		return count;
	}

	public String getHTMLTagContents(String html, String tagName) {
		String regex = "(<"+ tagName + ".*>)(.*)(<\\/"+ tagName +">)";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(html);
		
		String content = "";
		while(m.find()) {
			content = m.group(2);
		}
		return content;
	}

	public String[] getHTMLTagsContents(String html, String tagName) {
		String regex = "<"+ tagName +">\\s*?(.*?)?\\s*?(?=<)<\\/"+ tagName +">";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(html);
		
		List<String> items = new ArrayList<>();
		
		while(m.find()) {
			items.add(m.group(1));
		}
		String[] itemArray = new String[items.size()];

		for(int i=0; i<itemArray.length; i++) {
			itemArray[i] = items.get(i);
		}
		
		return itemArray;
	}

	public String[] getHTMLLinkURL(String html) {
		String regex = "(<a href=\"(.+?(?=\"))\">\\s?(.+?(?=<))?<\\/a>)";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(html);
		
		List<String> items = new ArrayList<>();
		
		while(m.find()) {
			items.add(m.group(2));
		}
		String[] itemArray = new String[items.size()];

		for(int i=0; i<itemArray.length; i++) {
			itemArray[i] = items.get(i);
		}
		
		return itemArray;
	}

}
