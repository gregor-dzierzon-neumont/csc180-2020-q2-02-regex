package edu.neumont.csc180.cox.regexutil;

import java.util.regex.Pattern;

import javax.naming.Name;

public class RegexHelper {
	
	public static boolean isValidHumanName(String name) {
	
		return name.matches("^[A-Za-z\\s.-]+$");
		
	}
	
	public static boolean isValidEmailAddress(String email) {
		return email.matches("^[A-Za-z][A-Za-z0-9\\_.]+@[A-Za-z]+[\\.][a-z]{3,4}$");
		
	}
	
	public static boolean isValidPhoneNumber(String phone) {
		return phone.matches("^[1-9]-\\([0-9]{3}\\)-[0-9]{3}-[0-9]{4}$");
	}
	
	boolean isValidSSN(String ssn) {
		return ssn.matches("^(?!000)(?!666)[0-9]{3}-[0-9]{2}-[0-9]{4}$");
	}
	/*
	boolean isValidUSStreetAddress(String street) {
		return;
	}
	boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower, int minNumeric, int minSymbols) {
		return;
	}
	*/
}
