package lopez.sear.regexutility;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexHelper implements RegexUtility {

    private static final String nameRegEx = "^((?:(M(?:is)?s|(?:Mrs?)|(Dr)))\\. )*+([A-Z][a-z]* [A-Z]. [A-Z][a-z]*)$";
    private static final String emailRegEx = "^((?!\\.?[0-9])[(A-Za-z)-_.]*[^.])(?<![0-9])@((?!\\.?[0-9])[(A-Za-z)-_.]*[^.])\\.([\\w]{3,4})$";
    private static final String phoneRegEx = "(\\d{1,2})[-](\\d{3})-(\\d{3})-(\\d{4})|(\\d{3})-(\\d{3})-(\\d{4})$";
    private static final String ssnRegEx = "^(?!666|000|9\\d{2})\\d{3}-(?!00)\\d{2}-(?!0{4})\\d{4}$";
    private static final String streetAddressRegex = "\\d+[ ](?:[A-Za-z0-9.-]+[ ]?)+(?:Avenue|Lane|Road|Boulevard|Drive|Street|Ave|Dr|Rd|Blvd|Ln|St|Terrace|Pkwy)\\.?, (?:[A-Z][a-z.-]+[ ]?)+, ([AL|AK|AS|AZ|AR|CA|CO|CT|DE|DC|FM|FL|GA|GU|HI|ID|IL|IN|IA|KS|KY|LA|ME|MH|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|MP|OH|OK|OR|PW|PA|PR|RI|SC|SD|TN|TX|UT|VT|VI|VA|WA|WV|WI|WY]{2}), (\\b\\d{5}(?:-\\d{4})?\\b)";


    private static final String getHTMLRegex = "<a.* href=\"(https://.*?)\".*>.*</a>";
    private static final String tagsContents = "<a(.*)?>(.*)</a>";
    private static final String countRegex = "\\{[^}]+\\}";

    public boolean isValidHumanName(String name) {
        return name.matches(nameRegEx);
    }

    public boolean isValidEmailAddress(String email) {
        return email.matches(emailRegEx);
    }

    public boolean isValidPhoneNumber(String phone) {
        return phone.matches(phoneRegEx);
    }

    public boolean isValidSSN(String ssn) {
        return ssn.matches(ssnRegEx);
    }

    public boolean isValidUSStreetAddress(String street) {
        return street.matches(streetAddressRegex);

    }

    public boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower, int minNumeric, int minSymbols) {
        return false;
    }

    public int countContains(String needle, String haystack) {
        String countRegex = "\\{[" + needle + "]+\\}";
        int counter = 0;
        Pattern pattern = Pattern.compile(countRegex, Pattern.MULTILINE);
        Matcher matcher = pattern.matcher(haystack);
        List<String> urls = new ArrayList<>();
        while (matcher.find()) {
            urls.add(matcher.group(0));
            counter++;
        }
        return counter;
    }

    public String getHTMLTagContents(String html, String tagName) {

        String HTMLRegex = "<" + tagName + "(.*)?>(.*)</" + tagName + ">";
        Pattern pattern = Pattern.compile(HTMLRegex, Pattern.MULTILINE);
        Matcher matcher = pattern.matcher(html);

        List<String> urls = new ArrayList<>();
        while (matcher.find()) {
            urls.add(matcher.group(2));
        }

        String[] urlsArray = new String[urls.size()];
        for (int i = 0; i < urls.size(); i++) {
            urlsArray[i] = urls.get(i);
        }

        return urlsArray[0];

    }


    public String[] getHTMLTagsContents(String html, String tagName) {

        String HTMLRegex = "<" + tagName + "(.*)?>(.*)</" + tagName + ">";
        Pattern pattern = Pattern.compile(HTMLRegex, Pattern.MULTILINE);
        Matcher matcher = pattern.matcher(html);

        List<String> urls = new ArrayList<>();
        while (matcher.find()) {
            urls.add(matcher.group(2));
        }

        String[] urlsArray = new String[urls.size()];
        for (int i = 0; i < urls.size(); i++) {
            urlsArray[i] = urls.get(i);
        }

        return urlsArray;
    }

    public String[] getHTMLLinkURL(String html) {

        Pattern pattern = Pattern.compile(getHTMLRegex, Pattern.MULTILINE);
        Matcher matcher = pattern.matcher(html);
        List<String> urls = new ArrayList<>();
        while (matcher.find()) {
            urls.add(matcher.group(1));
        }

        String[] urlsArray = new String[urls.size()];
        for (int i = 0; i < urls.size(); i++) {
            urlsArray[i] = urls.get(i);
        }

        return urlsArray;
    }
}
