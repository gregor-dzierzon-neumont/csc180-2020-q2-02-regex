package lopez.sear.regexutility;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class RegexTester {

    private RegexHelper regexHelper;

    @Before
    public void init() {
        regexHelper = new RegexHelper();
    }

    @Test
    public void testValidHumanName() {
        Assert.assertTrue(regexHelper.isValidHumanName("Searjasub S. Lopez"));
    }

    @Test
    public void testValidPhoneNumber() {
        Assert.assertTrue(regexHelper.isValidPhoneNumber("453-546-8986"));
    }

    @Test
    public void testValidEmailAddress() {
        Assert.assertTrue(regexHelper.isValidEmailAddress("rcox@neumont.edu"));
    }

    @Test
    public void testIsValidSSN() {
        Assert.assertTrue(regexHelper.isValidSSN("872-78-1823"));
    }

    @Test
    public void testIsValidUSStreetAddress() {
        Assert.assertTrue(regexHelper.isValidUSStreetAddress("1804 Club Pkwy, Nashville, TN, 37221"));
    }

    @Test
    public void testCountContains(){
        Assert.assertEquals(2, regexHelper.countContains("world", "heloo {world} sometig like {world} asd"));
    }

    @Test
    public void testGetHTMLTagContents() {
        Assert.assertEquals("cool content", regexHelper.getHTMLTagContents("<a href=\"https://secondLink\">cool content</a>", "a"));
    }

    @Test
    public void testGetHTMLTagsContents() {
        String[] expected = new String[]{"link", "link2"};
        Assert.assertArrayEquals(expected, regexHelper.getHTMLTagsContents("<a href=\"https://secondLink\">link</a>\n<a href=\"https://secondLink\">link2</a>", "a"));
    }

    @Test
    public void testGetHTMLLinkURL() {
        String[] expected = new String[]{"https://something", "https://secondLink"};
        Assert.assertArrayEquals(expected, regexHelper.getHTMLLinkURL("<a href=\"https://something\">link</a>\n<a href=\"https://secondLink\">link</a>"));
    }
}
